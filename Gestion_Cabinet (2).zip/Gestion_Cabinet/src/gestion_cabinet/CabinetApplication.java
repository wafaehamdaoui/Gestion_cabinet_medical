/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/Application.java to edit this template
 */
package gestion_cabinet;

//import java.awt.Component;
import java.awt.Desktop;
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.awt.print.PrinterJob;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.util.GregorianCalendar;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.io.File;
import java.nio.file.Files;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.standard.Destination;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;

/**
 *
 * @author Hello
 */
public class CabinetApplication extends javax.swing.JFrame {

    // Cette biblio nous permet de se connecter avec la base de donne et passer des requettes
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    double first;
    double seconde;
    double result;
    String operation;
    String dd ;
    String dat;
    String Num;
    String Num1;
    
    ImageIcon logo = new ImageIcon(System.getProperty("user.dir")+File.separator+"Capture.PNG");
    
    
    public CabinetApplication() {
        initComponents();
        table();
        table2();
        table3();
        Heure();
        dt();
        String path = System.getProperty("user.dir")+File.separator+"Documents";
        File dir = new File(path);
        if(!dir.exists()){
            if(!dir.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
        String path1 = System.getProperty("user.dir")+File.separator+"Documents\\Certificats";
        File dir1 = new File(path1);
        if(!dir1.exists()){
            if(!dir1.mkdir()){
                JOptionPane.showMessageDialog(null, "Successfully...");
            }
        }
        String path2 = System.getProperty("user.dir")+File.separator+"Documents\\Ordonnances";
        File dir2 = new File(path2);
        if(!dir2.exists()){
            if(!dir2.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
        String path3 = System.getProperty("user.dir")+File.separator+"Documents\\Comptes Rendus";
        File dir3 = new File(path3);
        if(!dir3.exists()){
            if(!dir3.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
        String path6 = System.getProperty("user.dir")+File.separator+"Documents\\Résumés";
        File dir6 = new File(path6);
        if(!dir6.exists()){
            if(!dir6.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
        
        String path4 = System.getProperty("user.dir")+File.separator+"Documents\\Dossiers Medicals";
        File dir4 = new File(path4);
        if(!dir4.exists()){
            if(!dir4.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
        String path5 = System.getProperty("user.dir")+File.separator+"Documents\\Factures";
        File dir5 = new File(path5);
        if(!dir5.exists()){
            if(!dir5.mkdir()){
                JOptionPane.showMessageDialog(null, "Failed...");
            }
        }
    }
    
    public void dt(){
        // la partie Date;
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        dd = sdf.format(d);
        date.setText(dd);
    }

    public void Heure (){
        Thread th = new Thread(){
            public void run(){
                for(;;){
                    try {
                        Calendar cal = new GregorianCalendar();
                        // la partie heure
                        int heure = cal.get(Calendar.HOUR_OF_DAY);
                        int minute = cal.get(Calendar.MINUTE);
                        int seconde = cal.get(Calendar.SECOND);
                        //if(moi<10){
                           // date.setText(jour+"/0"+moi+"/"+annee);
                           // date1.setText("Temara Le : "+jour+"/0"+moi+"/"+annee);
                        //}else{
                          //  date.setText(jour+"/"+moi+"/"+annee);
                          //  date1.setText("Temara Le : "+jour+"/"+moi+"/"+annee);
                       // }
                        
                        hour.setText(heure+":"+minute+":"+seconde);
                        sleep(1000);
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                }
            }
        };
        th.start();
    }
    
    public void Connect(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\Patients.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch(Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    public void Connect12(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\cabinet.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch(Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    
    public void table9(){
        dat = dd.substring(3, 10);
        String []col = {"Mois","NOMBRE"};
        DefaultTableModel model = new DefaultTableModel(null,col);
        
        int k=0;
        for(int i=0 ; i<jTable2.getRowCount(); i++){
            if(jTable2.getValueAt(i,4 ).toString().toLowerCase().endsWith(dat)){
                k++;
            }
        }
        String []row = {dat,String.valueOf(k)};
        model.addRow(row);
        jTable9.setModel(model);
    }
    
    public void table10(){
        dat = dd.substring(3, 10);
        String []col = {"Mois","NOMBRE"};
        DefaultTableModel model = new DefaultTableModel(null,col);
        
        int k=0;
        for(int i=0 ; i<jTable3.getRowCount(); i++){
            if(jTable3.getValueAt(i,2 ).toString().toLowerCase().endsWith(dat)){
                k++;
            }
        }
        String []row = {dat,String.valueOf(k)};
        model.addRow(row);
        jTable10.setModel(model);
    }
    
     public void table11(){
        dat = dd.substring(3, 10);
        String []col = {"Mois","NOMBRE"};
        DefaultTableModel model = new DefaultTableModel(null,col);
        
        int k=0;
        for(int i=0 ; i<jTable3.getRowCount(); i++){
            if(jTable3.getValueAt(i,2 ).toString().toLowerCase().endsWith(dat) && "contrôle".equals(jTable3.getValueAt(i,4 ).toString().toLowerCase())){
                k++;
            }
        }
        String []row = {dat,String.valueOf(k)};
        model.addRow(row);
        jTable11.setModel(model);
    }
    
    public void table12(){
        String []patient = {"CODE","NOM UTILISATEUR"};
        String []montrer = new String[2];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from login";
        try{
            Connect12();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                model.addRow(montrer);
            }
            jTable12.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void table13(){
        dat = dd.substring(3, 10);
        String []col = {"Mois","NOMBRE"};
        DefaultTableModel model = new DefaultTableModel(null,col);
        
        int k=0;
        for(int i=0 ; i<jTable3.getRowCount(); i++){
            if(jTable3.getValueAt(i,2 ).toString().toLowerCase().endsWith(dat) && "consultation".equals(jTable3.getValueAt(i,4 ).toString().toLowerCase())){
                k++;
            }
        }
        String []row = {dat,String.valueOf(k)};
        model.addRow(row);
        jTable13.setModel(model);
    }
     public void table(){
        String []patient = {"CODE","NOM","DATE_NAISSANCE","PROFESSION","ADRESSE","MUTUELLE","SITUATION_FAMILIALE","CIN","TELEPHONE"};
        String []montrer = new String[10];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from patient";
        try{
            Connect();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("date");
                montrer[3] = rs.getString("profession");
                montrer[4] = rs.getString("address");
                montrer[5] = rs.getString("mutuelle");
                montrer[6] = rs.getString("situation");
                montrer[7] = rs.getString("cin");
                montrer[8] = rs.getString("phone");
                model.addRow(montrer);
            }
            jTable1.setModel(model);
            jTable5.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void Connect2(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\Rendez.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch (Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    
    public void Connect3(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\Consultations.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch (Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    
    public void Connect4(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\Reglement.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch (Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    
    public void Connect5(){
        try{
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:"+System.getProperty("user.dir")+File.separator+"MyDB\\Charges.db");
            //JOptionPane.showMessageDialog(null, " connection etablie");
        } catch (Exception e){
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, " connection echouée");
        }
    }
    
    public void table2(){
        String []patient = {"NUM_RDV","CODE","PATIENTE","HEURE","STATUS","DATE","MOTIF","TYPE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from rendez";
        try{
            Connect2();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("num");
                montrer[1] = rs.getString("code");
                montrer[2] = rs.getString("nom");
                montrer[3] = rs.getString("heure");
                montrer[4] = rs.getString("status");
                montrer[5] = rs.getString("date");
                montrer[6] = rs.getString("motif");
                montrer[7] = rs.getString("commentaire");
                model.addRow(montrer);
            }
            jTable2.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void table3(){
        String []patient = {"NUM_CONSULTATION","CODE","PATIENTE","DATE","MOTIF","COMMENTAIRE"};
        String []montrer = new String[6];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from consultation";
        try{
            Connect3();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("num");
                montrer[1] = rs.getString("code");
                montrer[2] = rs.getString("nom");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("motif");
                montrer[5] = rs.getString("diagnostic");
                model.addRow(montrer);
            }
            jTable3.setModel(model);
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void table4(){
        String value = date.getText();
        String []patient = {"CODE","PATIENT","HEURE","STATUS","DATE","MOTIF","TYPE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from rendez where date='"+value+"' and status='EN ATTENTE'";
        try{
            Connect2();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("heure");
                montrer[3] = rs.getString("status");
                montrer[4] = rs.getString("date");
                montrer[5] = rs.getString("motif");
                montrer[6] = rs.getString("commentaire");
                model.addRow(montrer);
            }
            jTable4.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
        public void table5(){

        String []patient = {"NUM_REGLEMENT","CODE","PATIENT","DATE","ACTES_MEDICAUX","MONTANT","PAIEMENT","RESTE A PAYE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from Reglements";
        try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("num");
                montrer[1] = rs.getString("code");
                montrer[2] = rs.getString("patient");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("actes");
                montrer[5] = rs.getString("montant");
                montrer[6] = rs.getString("paiement");
                montrer[7] = rs.getString("reste");
                model.addRow(montrer);
            }
            jTable6.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void table6(){
        String []patient = {"CODE","TYPE","MONTANT","DATE","ETAT","OBSERVATION"};
        String []montrer = new String[6];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from charge";
        try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("type");
                montrer[2] = rs.getString("montant");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("etat");
                montrer[5] = rs.getString("observation");
                model.addRow(montrer);
            }
            jTable7.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        txtnom = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtmutuelle = new javax.swing.JTextField();
        txtprofession = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtcin = new javax.swing.JTextField();
        txtsituation = new javax.swing.JTextField();
        txtdate = new javax.swing.JFormattedTextField();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        txtaddress = new javax.swing.JTextField();
        txtphone = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        jDialog2 = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtnom1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtphone1 = new javax.swing.JTextField();
        txtsituation1 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtmutuelle1 = new javax.swing.JTextField();
        txtadress1 = new javax.swing.JTextField();
        txtdate1 = new javax.swing.JFormattedTextField();
        txtprofession1 = new javax.swing.JTextField();
        jLabel127 = new javax.swing.JLabel();
        txtcin1 = new javax.swing.JTextField();
        jLabel128 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jDialog4 = new javax.swing.JDialog();
        jPanel6 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txt = new javax.swing.JLabel();
        txt1 = new javax.swing.JLabel();
        txt2 = new javax.swing.JLabel();
        txtheure = new javax.swing.JComboBox<>();
        txt3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtmotif = new javax.swing.JTextPane();
        txtdate2 = new javax.swing.JFormattedTextField();
        txtstatus = new javax.swing.JComboBox<>();
        txt8 = new javax.swing.JLabel();
        txt9 = new javax.swing.JLabel();
        txtcom = new javax.swing.JComboBox<>();
        jButton23 = new javax.swing.JButton();
        jTextField43 = new javax.swing.JTextField();
        cancelButton2 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jDialog5 = new javax.swing.JDialog();
        jPanel7 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        txt10 = new javax.swing.JLabel();
        txt11 = new javax.swing.JLabel();
        txt12 = new javax.swing.JLabel();
        txtheure1 = new javax.swing.JComboBox<>();
        txt13 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtmotif1 = new javax.swing.JTextPane();
        txtdate3 = new javax.swing.JFormattedTextField();
        txtstatus1 = new javax.swing.JComboBox<>();
        txt14 = new javax.swing.JLabel();
        txt15 = new javax.swing.JLabel();
        txtcom1 = new javax.swing.JComboBox<>();
        jTextField45 = new javax.swing.JTextField();
        jButton25 = new javax.swing.JButton();
        jDialog7 = new javax.swing.JDialog();
        jPanel8 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        txtmotif2 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        txtdate4 = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane35 = new javax.swing.JScrollPane();
        txtdiagno2 = new javax.swing.JTextArea();
        jTextField44 = new javax.swing.JTextField();
        jButton24 = new javax.swing.JButton();
        cancelButton4 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jDialog8 = new javax.swing.JDialog();
        jPanel11 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        txtmotif3 = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txtdate5 = new javax.swing.JFormattedTextField();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane37 = new javax.swing.JScrollPane();
        txtdiagno3 = new javax.swing.JTextArea();
        jTextField46 = new javax.swing.JTextField();
        jButton26 = new javax.swing.JButton();
        cancelButton5 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jDialog10 = new javax.swing.JDialog();
        jPanel13 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        Modifier = new javax.swing.JMenuItem();
        Supprimer = new javax.swing.JMenuItem();
        jPopupMenu2 = new javax.swing.JPopupMenu();
        Modifier1 = new javax.swing.JMenuItem();
        Supprimer1 = new javax.swing.JMenuItem();
        jPopupMenu3 = new javax.swing.JPopupMenu();
        Modifier2 = new javax.swing.JMenuItem();
        Supprimer2 = new javax.swing.JMenuItem();
        jDialog13 = new javax.swing.JDialog();
        jPanel20 = new javax.swing.JPanel();
        jLabel60 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jFrame3 = new javax.swing.JFrame();
        jPanel21 = new javax.swing.JPanel();
        txt4 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        jcode = new javax.swing.JTextPane();
        jScrollPane14 = new javax.swing.JScrollPane();
        jnom = new javax.swing.JTextPane();
        jScrollPane15 = new javax.swing.JScrollPane();
        jphone = new javax.swing.JTextPane();
        txt5 = new javax.swing.JLabel();
        txt6 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        txt7 = new javax.swing.JLabel();
        txt16 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        txtmotif8 = new javax.swing.JTextPane();
        jScrollPane19 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        txt18 = new javax.swing.JLabel();
        jScrollPane22 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jPanel22 = new javax.swing.JPanel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        txt23 = new javax.swing.JLabel();
        jScrollPane38 = new javax.swing.JScrollPane();
        txtmotif9 = new javax.swing.JTextPane();
        jScrollPane39 = new javax.swing.JScrollPane();
        txtmotif10 = new javax.swing.JTextPane();
        txt24 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenu7 = new javax.swing.JMenu();
        jFrame4 = new javax.swing.JFrame();
        jPanel23 = new javax.swing.JPanel();
        Display = new javax.swing.JTextField();
        jBut1 = new javax.swing.JButton();
        jBut2 = new javax.swing.JButton();
        jBut3 = new javax.swing.JButton();
        jBut4 = new javax.swing.JButton();
        jBut5 = new javax.swing.JButton();
        jBut6 = new javax.swing.JButton();
        jBut7 = new javax.swing.JButton();
        jBut8 = new javax.swing.JButton();
        jBut9 = new javax.swing.JButton();
        jBut10 = new javax.swing.JButton();
        jBut11 = new javax.swing.JButton();
        jBut12 = new javax.swing.JButton();
        jBut13 = new javax.swing.JButton();
        jBut14 = new javax.swing.JButton();
        jBut15 = new javax.swing.JButton();
        jBut16 = new javax.swing.JButton();
        jFrame5 = new javax.swing.JFrame();
        jPanel24 = new javax.swing.JPanel();
        txt17 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        jcode1 = new javax.swing.JTextPane();
        txt19 = new javax.swing.JLabel();
        txt20 = new javax.swing.JLabel();
        jFormattedTextField2 = new javax.swing.JFormattedTextField();
        jFormattedTextField3 = new javax.swing.JFormattedTextField();
        txt21 = new javax.swing.JLabel();
        txt22 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        txtstatus3 = new javax.swing.JComboBox<>();
        jScrollPane18 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jPanel25 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        txtstatus2 = new javax.swing.JComboBox<>();
        jLabel198 = new javax.swing.JLabel();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu10 = new javax.swing.JMenu();
        jMenu11 = new javax.swing.JMenu();
        jMenu12 = new javax.swing.JMenu();
        jMenu13 = new javax.swing.JMenu();
        jFrame10 = new javax.swing.JFrame();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel214 = new javax.swing.JLabel();
        jScrollPane42 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        jLabel221 = new javax.swing.JLabel();
        jScrollPane44 = new javax.swing.JScrollPane();
        jTable13 = new javax.swing.JTable();
        jPanel41 = new javax.swing.JPanel();
        jLabel210 = new javax.swing.JLabel();
        jLabel211 = new javax.swing.JLabel();
        jLabel212 = new javax.swing.JLabel();
        jScrollPane40 = new javax.swing.JScrollPane();
        jTable9 = new javax.swing.JTable();
        jLabel219 = new javax.swing.JLabel();
        jLabel220 = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel204 = new javax.swing.JLabel();
        jLabel205 = new javax.swing.JLabel();
        jLabel206 = new javax.swing.JLabel();
        jLabel207 = new javax.swing.JLabel();
        jLabel208 = new javax.swing.JLabel();
        jLabel209 = new javax.swing.JLabel();
        jScrollPane41 = new javax.swing.JScrollPane();
        jTable10 = new javax.swing.JTable();
        jLabel213 = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        jLabel215 = new javax.swing.JLabel();
        jLabel216 = new javax.swing.JLabel();
        jLabel217 = new javax.swing.JLabel();
        jLabel218 = new javax.swing.JLabel();
        jFrame11 = new javax.swing.JFrame();
        jPanel43 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jScrollPane43 = new javax.swing.JScrollPane();
        jTable12 = new javax.swing.JTable();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jFrame12 = new javax.swing.JFrame();
        jPanel44 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        jButton22 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel47 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField2 = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jTextField3 = new javax.swing.JTextField();
        date = new javax.swing.JLabel();
        hour = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        fileMenu = new javax.swing.JMenu();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenu14 = new javax.swing.JMenu();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        cutMenuItem = new javax.swing.JMenuItem();
        copyMenuItem = new javax.swing.JMenuItem();
        pasteMenuItem = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        contentsMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenu9 = new javax.swing.JMenu();
        jMenu15 = new javax.swing.JMenu();
        jMenu16 = new javax.swing.JMenu();

        jDialog1.setTitle("Ajouter Patient");
        jDialog1.setIconImage(logo.getImage());
        jDialog1.setLocation(new java.awt.Point(300, 100));
        jDialog1.setSize(new java.awt.Dimension(531, 532));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 0, 51));
        jLabel11.setText("AJOUTER NOUVELLE PATIENTE");

        jPanel3.setBackground(new java.awt.Color(204, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255)), "Patient information", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        txtnom.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtnom.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnom.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtnom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 153, 255));
        jLabel2.setText("Nom Complet :");

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 153, 255));
        jLabel3.setText("Profession :");

        txtmutuelle.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtmutuelle.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtmutuelle.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtmutuelle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmutuelleActionPerformed(evt);
            }
        });

        txtprofession.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtprofession.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtprofession.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtprofession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprofessionActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 153, 255));
        jLabel4.setText("CIN :");

        jLabel5.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 153, 255));
        jLabel5.setText("Date De Naissance :");

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 153, 255));
        jLabel6.setText("Mutuelle :");

        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 153, 255));
        jLabel7.setText("Situation Famialiale :");

        txtcin.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtcin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtcin.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtcin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcinActionPerformed(evt);
            }
        });

        txtsituation.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtsituation.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtsituation.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtsituation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsituationActionPerformed(evt);
            }
        });

        txtdate.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        try {
            txtdate.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtdate.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdateActionPerformed(evt);
            }
        });

        jLabel125.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel125.setForeground(new java.awt.Color(102, 153, 255));
        jLabel125.setText("Adresse :");

        jLabel126.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel126.setForeground(new java.awt.Color(102, 153, 255));
        jLabel126.setText("Telephone :");

        txtaddress.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtaddress.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtaddress.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtaddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtaddressActionPerformed(evt);
            }
        });

        txtphone.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtphone.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtphone.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtphone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtphoneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtprofession, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtaddress, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel125, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))))))
                .addGap(34, 34, 34)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGap(0, 17, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtmutuelle, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtsituation, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                            .addComponent(txtcin, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtphone, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel126, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtmutuelle, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtsituation, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .addComponent(txtdate))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtprofession, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcin, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel125, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel126, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtaddress, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtphone, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jButton7.setBackground(new java.awt.Color(0, 204, 102));
        jButton7.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Ajouter");
        jButton7.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        cancelButton.setBackground(new java.awt.Color(255, 102, 51));
        cancelButton.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        cancelButton.setForeground(new java.awt.Color(255, 255, 255));
        cancelButton.setText("Annuler");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(169, 169, 169)
                        .addComponent(cancelButton)
                        .addGap(37, 37, 37)
                        .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(jLabel11)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDialog2.setTitle("Modifier Patient");
        jDialog2.setIconImage(logo.getImage());
        jDialog2.setLocation(new java.awt.Point(200, 100));
        jDialog2.setSize(new java.awt.Dimension(440, 525));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 0, 51));
        jLabel12.setText("MODIFIER PATIENTE");

        jPanel4.setBackground(new java.awt.Color(204, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255)), "Patient information", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        txtnom1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtnom1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnom1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtnom1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnom1ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 153, 255));
        jLabel13.setText("Nom Complet");

        jLabel14.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(102, 153, 255));
        jLabel14.setText("Situation Familiale");

        txtphone1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtphone1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtphone1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtphone1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtphone1ActionPerformed(evt);
            }
        });

        txtsituation1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtsituation1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtsituation1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtsituation1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsituation1ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 153, 255));
        jLabel15.setText("Téléphone");

        jLabel16.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(102, 153, 255));
        jLabel16.setText("Date De Naissance");

        jLabel17.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(102, 153, 255));
        jLabel17.setText("Adresse");

        jLabel18.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(102, 153, 255));
        jLabel18.setText("Mutuelle");

        txtmutuelle1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtmutuelle1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtmutuelle1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtmutuelle1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmutuelle1ActionPerformed(evt);
            }
        });

        txtadress1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtadress1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtadress1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtadress1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtadress1ActionPerformed(evt);
            }
        });

        txtdate1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        try {
            txtdate1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtdate1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtdate1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdate1ActionPerformed(evt);
            }
        });

        txtprofession1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtprofession1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtprofession1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtprofession1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprofession1ActionPerformed(evt);
            }
        });

        jLabel127.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel127.setForeground(new java.awt.Color(102, 153, 255));
        jLabel127.setText("Profession");

        txtcin1.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        txtcin1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtcin1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtcin1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcin1ActionPerformed(evt);
            }
        });

        jLabel128.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel128.setForeground(new java.awt.Color(102, 153, 255));
        jLabel128.setText("CIN");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtadress1)
                    .addComponent(txtdate1)
                    .addComponent(txtprofession1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtnom1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel127, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 5, Short.MAX_VALUE)))
                .addGap(33, 33, 33)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtcin1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtmutuelle1, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtsituation1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)))
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel128, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addContainerGap()))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(txtphone1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnom1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtmutuelle1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtdate1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtsituation1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel127, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel128, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtprofession1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcin1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtphone1, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .addComponent(txtadress1))
                .addContainerGap())
        );

        jButton3.setBackground(new java.awt.Color(255, 102, 51));
        jButton3.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Annuler");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 102, 255));
        jButton2.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Modifier");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(114, 114, 114)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3)
                    .addComponent(jButton2))
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog2Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDialog4.setTitle("Ajouter RDV");
        jDialog4.setIconImage(logo.getImage());
        jDialog4.setLocation(new java.awt.Point(390, 200));
        jDialog4.setSize(new java.awt.Dimension(460, 450));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(51, 0, 51));
        jLabel24.setText("AJOUTER NOUVEAU RDV");

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 2, true), "Gestion De Rendez-vous", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        txt.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt.setForeground(new java.awt.Color(102, 153, 255));
        txt.setText("Date");

        txt1.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt1.setForeground(new java.awt.Color(102, 153, 255));
        txt1.setText("Patiente");

        txt2.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt2.setForeground(new java.awt.Color(102, 153, 255));
        txt2.setText("Motif");

        txtheure.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtheure.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "9 : 00", "9 : 30", "10 : 00", "10 : 30", "11 : 00", "11 : 30", "12 : 00", "12 : 30", "13 : 00", "13 : 30", "14 : 00", "14 : 30", "15 : 00", "15 : 30", "16 : 00", "16 : 30", "17 : 00", "17 : 30", " " }));

        txt3.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt3.setForeground(new java.awt.Color(102, 153, 255));
        txt3.setText("Heure");

        txtmotif.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane4.setViewportView(txtmotif);

        try {
            txtdate2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtstatus.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtstatus.setMaximumRowCount(2000);
        txtstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "En Attente", "Terminé", "Annulé" }));

        txt8.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt8.setForeground(new java.awt.Color(102, 153, 255));
        txt8.setText("Status");

        txt9.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt9.setForeground(new java.awt.Color(102, 153, 255));
        txt9.setText("Type");

        txtcom.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtcom.setMaximumRowCount(2000);
        txtcom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Consultation", "Contrôle", " " }));

        jButton23.setBackground(new java.awt.Color(0, 204, 255));
        jButton23.setText("choisir");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jTextField43.setEditable(false);
        jTextField43.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtheure, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtstatus, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextField43, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(txt3, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(txt8, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(txt1)
                                    .addGap(18, 18, 18)
                                    .addComponent(jButton23))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(30, 30, 30)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtdate2)
                    .addComponent(jScrollPane4)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(txt9, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(txt, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(txt2, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 32, Short.MAX_VALUE))
                    .addComponent(txtcom, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton23))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(txtdate2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jTextField43))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtheure, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(jScrollPane4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt8)
                    .addComponent(txt9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstatus, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(txtcom))
                .addGap(177, 177, 177))
        );

        cancelButton2.setBackground(new java.awt.Color(255, 102, 51));
        cancelButton2.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        cancelButton2.setForeground(new java.awt.Color(255, 255, 255));
        cancelButton2.setText("Annuler");
        cancelButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton2ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(0, 204, 102));
        jButton8.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Ajouter");
        jButton8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(cancelButton2)
                        .addGap(54, 54, 54)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cancelButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout jDialog4Layout = new javax.swing.GroupLayout(jDialog4.getContentPane());
        jDialog4.getContentPane().setLayout(jDialog4Layout);
        jDialog4Layout.setHorizontalGroup(
            jDialog4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialog4Layout.setVerticalGroup(
            jDialog4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDialog5.setTitle("Modifier RDV");
        jDialog5.setIconImage(logo.getImage());
        jDialog5.setLocation(new java.awt.Point(390, 200));
        jDialog5.setSize(new java.awt.Dimension(500, 455));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(51, 0, 51));
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("Midifier Rendez-vous");

        jButton5.setBackground(new java.awt.Color(255, 102, 51));
        jButton5.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Annuler");
        jButton5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 102, 255));
        jButton6.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Modifier");
        jButton6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(204, 255, 204));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 2, true), "Gestion De Rendez-vous", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        txt10.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt10.setForeground(new java.awt.Color(102, 153, 255));
        txt10.setText("Date");

        txt11.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt11.setForeground(new java.awt.Color(102, 153, 255));
        txt11.setText("Patiente");

        txt12.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt12.setForeground(new java.awt.Color(102, 153, 255));
        txt12.setText("Motif");

        txtheure1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtheure1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "9 : 00", "9 : 30", "10 : 00", "10 : 30", "11 : 00", "11 : 30", "12 : 00", "12 : 30", "13 : 00", "13 : 30", "14 : 00", "14 : 30", "15 : 00", "15 : 30", "16 : 00", "16 : 30", "17 : 00", "17 : 30", " " }));

        txt13.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt13.setForeground(new java.awt.Color(102, 153, 255));
        txt13.setText("Heure");

        txtmotif1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane7.setViewportView(txtmotif1);

        try {
            txtdate3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtstatus1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtstatus1.setMaximumRowCount(2000);
        txtstatus1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "en attente", "terminé", "annulé" }));

        txt14.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt14.setForeground(new java.awt.Color(102, 153, 255));
        txt14.setText("Status");

        txt15.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt15.setForeground(new java.awt.Color(102, 153, 255));
        txt15.setText("Type");

        txtcom1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        txtcom1.setMaximumRowCount(2000);
        txtcom1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "consultation", "contrôle", " " }));

        jTextField45.setEditable(false);
        jTextField45.setBackground(new java.awt.Color(255, 255, 255));
        jTextField45.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        jButton25.setBackground(new java.awt.Color(0, 204, 204));
        jButton25.setText("Changer");
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtheure1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtstatus1, 0, 154, Short.MAX_VALUE)
                    .addComponent(jTextField45)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(txt13, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(txt14, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(txt11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton25)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addComponent(txt10, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addComponent(txt12, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(62, 62, 62)
                                .addComponent(txt15, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 42, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtdate3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(txtcom1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(23, 23, 23))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt10, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton25))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(txtdate3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jTextField45))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt13, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt12, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtheure1, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(jScrollPane7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt14)
                    .addComponent(txt15, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstatus1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(txtcom1))
                .addGap(180, 180, 180))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton6)
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(25, 25, 25))
        );

        javax.swing.GroupLayout jDialog5Layout = new javax.swing.GroupLayout(jDialog5.getContentPane());
        jDialog5.getContentPane().setLayout(jDialog5Layout);
        jDialog5Layout.setHorizontalGroup(
            jDialog5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialog5Layout.setVerticalGroup(
            jDialog5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog5Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jDialog7.setTitle("Ajouter consultation");
        jDialog7.setIconImage(logo.getImage());
        jDialog7.setLocation(new java.awt.Point(390, 90));
        jDialog7.setSize(new java.awt.Dimension(550, 528));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel26.setBackground(new java.awt.Color(255, 255, 255));
        jLabel26.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(51, 0, 51));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Ajouter Consultation");

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255)), "Consultation information", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        jLabel23.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(102, 153, 255));
        jLabel23.setText("Patiente");

        jLabel27.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(102, 153, 255));
        jLabel27.setText("COMMENTAIRE");

        txtmotif2.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtmotif2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtmotif2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtmotif2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmotif2ActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(102, 153, 255));
        jLabel28.setText("Motif");

        jLabel29.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(102, 153, 255));
        jLabel29.setText("Date  ");

        txtdate4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        try {
            txtdate4.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtdate4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtdate4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdate4ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/Consul.PNG"))); // NOI18N

        txtdiagno2.setColumns(20);
        txtdiagno2.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtdiagno2.setLineWrap(true);
        txtdiagno2.setRows(5);
        jScrollPane35.setViewportView(txtdiagno2);

        jTextField44.setEditable(false);
        jTextField44.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        jButton24.setBackground(new java.awt.Color(0, 204, 255));
        jButton24.setText("choisir");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtdate4, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                            .addComponent(txtmotif2)
                            .addComponent(jTextField44))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane35, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addGap(43, 43, 43)
                        .addComponent(jButton24)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane35, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton24))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField44, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtmotif2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtdate4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21))
        );

        cancelButton4.setBackground(new java.awt.Color(255, 102, 51));
        cancelButton4.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        cancelButton4.setForeground(new java.awt.Color(255, 255, 255));
        cancelButton4.setText("Annuler");
        cancelButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton4ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(0, 204, 102));
        jButton10.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Ajouter");
        jButton10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(cancelButton4)
                        .addGap(51, 51, 51)
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(cancelButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialog7Layout = new javax.swing.GroupLayout(jDialog7.getContentPane());
        jDialog7.getContentPane().setLayout(jDialog7Layout);
        jDialog7Layout.setHorizontalGroup(
            jDialog7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialog7Layout.setVerticalGroup(
            jDialog7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDialog8.setTitle("Modifier");
        jDialog8.setIconImage(logo.getImage());
        jDialog8.setLocation(new java.awt.Point(390, 100));
        jDialog8.setSize(new java.awt.Dimension(550, 528));

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(51, 0, 51));
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("Modifier Consultation");

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255), new java.awt.Color(153, 204, 255)), "Consultation information", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Comic Sans MS", 0, 12), new java.awt.Color(153, 153, 255))); // NOI18N

        jLabel34.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(102, 153, 255));
        jLabel34.setText("Patiente");

        jLabel35.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(102, 153, 255));
        jLabel35.setText("COMMENTAIRE");

        txtmotif3.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtmotif3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtmotif3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        txtmotif3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmotif3ActionPerformed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(102, 153, 255));
        jLabel36.setText("Motif");

        jLabel37.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(102, 153, 255));
        jLabel37.setText("Date  ");

        txtdate5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255), new java.awt.Color(153, 153, 255)));
        try {
            txtdate5.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtdate5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtdate5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdate5ActionPerformed(evt);
            }
        });

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/Consul.PNG"))); // NOI18N

        txtdiagno3.setColumns(20);
        txtdiagno3.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        txtdiagno3.setLineWrap(true);
        txtdiagno3.setRows(5);
        jScrollPane37.setViewportView(txtdiagno3);

        jTextField46.setEditable(false);
        jTextField46.setBackground(new java.awt.Color(255, 255, 255));
        jTextField46.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        jButton26.setBackground(new java.awt.Color(0, 204, 204));
        jButton26.setText("Changer");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtmotif3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtdate5)
                            .addComponent(jTextField46))
                        .addGap(9, 9, 9))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 51, Short.MAX_VALUE)))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jScrollPane37, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(20, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70))))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel34)
                .addGap(34, 34, 34)
                .addComponent(jButton26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel41)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane37, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton26))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField46)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtmotif3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtdate5, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        cancelButton5.setBackground(new java.awt.Color(255, 102, 51));
        cancelButton5.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        cancelButton5.setForeground(new java.awt.Color(255, 255, 255));
        cancelButton5.setText("Annuler");
        cancelButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButton5ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(0, 153, 255));
        jButton11.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Modifier");
        jButton11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255)));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addComponent(cancelButton5)
                        .addGap(58, 58, 58)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(172, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGap(0, 33, Short.MAX_VALUE)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(cancelButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialog8Layout = new javax.swing.GroupLayout(jDialog8.getContentPane());
        jDialog8.getContentPane().setLayout(jDialog8Layout);
        jDialog8Layout.setHorizontalGroup(
            jDialog8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDialog8Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialog8Layout.setVerticalGroup(
            jDialog8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jDialog10.setTitle("Liste d 'Attente");
        jDialog10.setIconImage(logo.getImage());
        jDialog10.setLocation(new java.awt.Point(390, 100));
        jDialog10.setSize(new java.awt.Dimension(750, 400));

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        jLabel44.setBackground(new java.awt.Color(255, 255, 255));
        jLabel44.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(51, 0, 51));
        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/att.PNG"))); // NOI18N
        jLabel44.setText("Liste des RDV En Attente d'Aujoud'hui");

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable4.setShowGrid(true);
        jScrollPane5.setViewportView(jTable4);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel44)
                        .addGap(181, 181, 181))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 704, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jDialog10Layout = new javax.swing.GroupLayout(jDialog10.getContentPane());
        jDialog10.getContentPane().setLayout(jDialog10Layout);
        jDialog10Layout.setHorizontalGroup(
            jDialog10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jDialog10Layout.setVerticalGroup(
            jDialog10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        Modifier.setText("Modifier");
        Modifier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModifierActionPerformed(evt);
            }
        });
        jPopupMenu1.add(Modifier);

        Supprimer.setText("Supprimer");
        Supprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupprimerActionPerformed(evt);
            }
        });
        jPopupMenu1.add(Supprimer);

        Modifier1.setText("Modifier");
        Modifier1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Modifier1ActionPerformed(evt);
            }
        });
        jPopupMenu2.add(Modifier1);

        Supprimer1.setText("Annuler");
        Supprimer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Supprimer1ActionPerformed(evt);
            }
        });
        jPopupMenu2.add(Supprimer1);

        Modifier2.setText("Modifier");
        Modifier2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Modifier2ActionPerformed(evt);
            }
        });
        jPopupMenu3.add(Modifier2);

        Supprimer2.setText("Supprimer");
        Supprimer2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Supprimer2ActionPerformed(evt);
            }
        });
        jPopupMenu3.add(Supprimer2);

        jDialog13.setTitle("Choisir Patiente");
        jDialog13.setIconImage(logo.getImage());
        jDialog13.setLocation(new java.awt.Point(200, 100));
        jDialog13.setSize(new java.awt.Dimension(755, 385));

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));

        jLabel60.setBackground(new java.awt.Color(255, 255, 255));
        jLabel60.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(153, 153, 255));
        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel60.setText("Recherche Rapide par Nom");

        jTextField4.setBackground(new java.awt.Color(255, 229, 255));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jTextField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField4KeyReleased(evt);
            }
        });

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable5.setShowGrid(true);
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable5MouseReleased(evt);
            }
        });
        jScrollPane12.setViewportView(jTable5);

        jButton19.setBackground(new java.awt.Color(235, 235, 235));
        jButton19.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 102, 51));
        jButton19.setText("Annuler");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.setBackground(new java.awt.Color(235, 235, 235));
        jButton20.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(0, 51, 255));
        jButton20.setText("Choisir");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGap(286, 286, 286)
                        .addComponent(jButton19)
                        .addGap(32, 32, 32)
                        .addComponent(jButton20))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton19)
                    .addComponent(jButton20))
                .addContainerGap())
        );

        javax.swing.GroupLayout jDialog13Layout = new javax.swing.GroupLayout(jDialog13.getContentPane());
        jDialog13.getContentPane().setLayout(jDialog13Layout);
        jDialog13Layout.setHorizontalGroup(
            jDialog13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog13Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jDialog13Layout.setVerticalGroup(
            jDialog13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jFrame3.setTitle("Caisse");
        jFrame3.setBackground(new java.awt.Color(255, 255, 255));
        jFrame3.setIconImage(logo.getImage());
        jFrame3.setLocation(new java.awt.Point(50, 30));
        jFrame3.setSize(new java.awt.Dimension(1250, 660));

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Choisir Patiente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        txt4.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt4.setForeground(new java.awt.Color(102, 153, 255));
        txt4.setText("Code");

        jcode.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane13.setViewportView(jcode);

        jnom.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane14.setViewportView(jnom);

        jphone.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane15.setViewportView(jphone);

        txt5.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt5.setForeground(new java.awt.Color(102, 153, 255));
        txt5.setText("Nom");

        txt6.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt6.setForeground(new java.awt.Color(102, 153, 255));
        txt6.setText("Téléphone");

        jButton21.setBackground(new java.awt.Color(235, 235, 235));
        jButton21.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 102, 51));
        jButton21.setText("Choisir Patiente");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txt5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt6, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                    .addComponent(jScrollPane13)
                    .addComponent(jScrollPane15))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton21)
                .addGap(70, 70, 70))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(txt5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        txt7.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt7.setForeground(new java.awt.Color(102, 153, 255));
        txt7.setText("Montant Totale");

        txt16.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt16.setForeground(new java.awt.Color(102, 153, 255));
        txt16.setText("Date de Paiement");

        txtmotif8.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane17.setViewportView(txtmotif8);

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable6.setShowGrid(true);
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable6MouseReleased(evt);
            }
        });
        jScrollPane19.setViewportView(jTable6);

        txt18.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt18.setForeground(new java.awt.Color(102, 153, 255));
        txt18.setText("Liste des Actes Médicaux :");

        jTextArea4.setColumns(20);
        jTextArea4.setLineWrap(true);
        jTextArea4.setRows(5);
        jScrollPane22.setViewportView(jTextArea4);

        jPanel22.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Recherche Rapide Par", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 13))); // NOI18N

        jLabel63.setBackground(new java.awt.Color(255, 255, 255));
        jLabel63.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(0, 153, 153));
        jLabel63.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel63.setText("Nom Patiente : ");

        jLabel64.setBackground(new java.awt.Color(255, 255, 255));
        jLabel64.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(0, 153, 153));
        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel64.setText("Date de Règlement :");

        jTextField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField5KeyReleased(evt);
            }
        });

        jTextField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField6KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel64)
                    .addComponent(jLabel63))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField5)
                    .addComponent(jTextField6, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel63))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel64))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel65.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        try {
            jFormattedTextField1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTextField1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        txt23.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt23.setForeground(new java.awt.Color(102, 153, 255));
        txt23.setText("Reste à payer");

        txtmotif9.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane38.setViewportView(txtmotif9);

        txtmotif10.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane39.setViewportView(txtmotif10);

        txt24.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt24.setForeground(new java.awt.Color(102, 153, 255));
        txt24.setText("Paiement");

        jMenu4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/add.PNG"))); // NOI18N
        jMenu4.setText("Ajouter");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jMenu4MouseEntered(evt);
            }
        });
        jMenuBar1.add(jMenu4);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/modi.PNG"))); // NOI18N
        jMenu5.setText("Modifier");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        jMenu6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/delete.PNG"))); // NOI18N
        jMenu6.setText("Supprimer");
        jMenu6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu6MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu6);

        jMenu8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/calcul.PNG"))); // NOI18N
        jMenu8.setText("Calculatrice");
        jMenu8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu8MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu8);

        jMenu7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/remove.PNG"))); // NOI18N
        jMenu7.setText("Fermer");
        jMenu7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu7MouseClicked(evt);
            }
        });
        jMenu7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu7ActionPerformed(evt);
            }
        });
        jMenuBar1.add(jMenu7);

        jFrame3.setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrame3Layout.createSequentialGroup()
                .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addContainerGap(14, Short.MAX_VALUE)
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane22, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jFrame3Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt18, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jFrame3Layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame3Layout.createSequentialGroup()
                                                .addComponent(txt24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jScrollPane39, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame3Layout.createSequentialGroup()
                                                .addComponent(txt7, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane17))
                                            .addGroup(jFrame3Layout.createSequentialGroup()
                                                .addComponent(txt16)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame3Layout.createSequentialGroup()
                                        .addComponent(txt23, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane38, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 849, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(171, 171, 171))
        );
        jFrame3Layout.setVerticalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrame3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 437, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jFrame3Layout.createSequentialGroup()
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(txt18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt16, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane39, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt24, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt23, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane38, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 80, Short.MAX_VALUE)))
                .addGap(12, 12, 12))
        );

        jFrame4.setTitle("Calculatrice");
        jFrame4.setIconImage(logo.getImage());
        jFrame4.setLocation(new java.awt.Point(300, 200));
        jFrame4.setSize(new java.awt.Dimension(300, 400));

        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        Display.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Display.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jBut1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut1.setText("1");
        jBut1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut1ActionPerformed(evt);
            }
        });

        jBut2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut2.setText("2");
        jBut2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut2ActionPerformed(evt);
            }
        });

        jBut3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut3.setText("3");
        jBut3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut3ActionPerformed(evt);
            }
        });

        jBut4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut4.setText("4");
        jBut4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut4ActionPerformed(evt);
            }
        });

        jBut5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut5.setText("5");
        jBut5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut5ActionPerformed(evt);
            }
        });

        jBut6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut6.setText("6");
        jBut6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut6ActionPerformed(evt);
            }
        });

        jBut7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut7.setText("7");
        jBut7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut7ActionPerformed(evt);
            }
        });

        jBut8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut8.setText("8");
        jBut8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut8ActionPerformed(evt);
            }
        });

        jBut9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut9.setText("9");
        jBut9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut9ActionPerformed(evt);
            }
        });

        jBut10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jBut10.setText("0");
        jBut10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut10ActionPerformed(evt);
            }
        });

        jBut11.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut11.setText("+");
        jBut11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut11ActionPerformed(evt);
            }
        });

        jBut12.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut12.setText("-");
        jBut12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut12ActionPerformed(evt);
            }
        });

        jBut13.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut13.setText("C");
        jBut13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut13ActionPerformed(evt);
            }
        });

        jBut14.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut14.setText("=");
        jBut14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut14ActionPerformed(evt);
            }
        });

        jBut15.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut15.setText("*");
        jBut15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut15ActionPerformed(evt);
            }
        });

        jBut16.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jBut16.setText("/");
        jBut16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBut16ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(Display, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jBut5, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                                .addComponent(jBut1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBut9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jBut13, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jBut6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBut2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBut10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBut14, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE))
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jBut7, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                                    .addComponent(jBut3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel23Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jBut15, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                                    .addComponent(jBut11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jBut4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBut8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBut12, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                            .addComponent(jBut16, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(Display, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBut1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBut5, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut7, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut8, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBut9, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut10, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut11, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut12, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBut13, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut14, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut15, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBut16, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jFrame4Layout = new javax.swing.GroupLayout(jFrame4.getContentPane());
        jFrame4.getContentPane().setLayout(jFrame4Layout);
        jFrame4Layout.setHorizontalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame4Layout.setVerticalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jFrame5.setTitle("charges");
        jFrame5.setBackground(new java.awt.Color(255, 255, 255));
        jFrame5.setIconImage(logo.getImage());
        jFrame5.setIconImages(null);
        jFrame5.setLocation(new java.awt.Point(150, 100));
        jFrame5.setSize(new java.awt.Dimension(955, 590));

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));
        jPanel24.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Charge Information", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        txt17.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt17.setText("Type");

        jcode1.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N
        jScrollPane16.setViewportView(jcode1);

        txt19.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt19.setText("Montant");

        txt20.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt20.setText("Date");

        try {
            jFormattedTextField2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFormattedTextField2.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        jFormattedTextField3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        jFormattedTextField3.setFont(new java.awt.Font("Comic Sans MS", 0, 14)); // NOI18N

        txt21.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt21.setText("Etat");

        txt22.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        txt22.setText("Observation");

        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jScrollPane23.setViewportView(jTextArea5);

        txtstatus3.setFont(new java.awt.Font("Arial Narrow", 0, 16)); // NOI18N
        txtstatus3.setMaximumRowCount(2000);
        txtstatus3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "payé", "impayé", " " }));

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel24Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(txt20, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt17, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt21, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt22, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(jFormattedTextField2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jFormattedTextField3)
                            .addComponent(txtstatus3, 0, 210, Short.MAX_VALUE))))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txt17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt19, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jFormattedTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jFormattedTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt20, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt21, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtstatus3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(txt22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(58, Short.MAX_VALUE))
        );

        jTable7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable7.setShowGrid(true);
        jTable7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable7MouseReleased(evt);
            }
        });
        jScrollPane18.setViewportView(jTable7);

        jPanel25.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Recherche Rapide Par", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Segoe UI", 0, 13))); // NOI18N

        jLabel68.setBackground(new java.awt.Color(255, 255, 255));
        jLabel68.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel68.setText("Type");

        jLabel70.setBackground(new java.awt.Color(255, 255, 255));
        jLabel70.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel70.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel70.setText("Date ");

        jTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField7KeyReleased(evt);
            }
        });

        jTextField8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField8KeyReleased(evt);
            }
        });

        jLabel71.setBackground(new java.awt.Color(255, 255, 255));
        jLabel71.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel71.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel71.setText("Etat");

        txtstatus2.setFont(new java.awt.Font("Arial Narrow", 0, 16)); // NOI18N
        txtstatus2.setMaximumRowCount(2000);
        txtstatus2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Payé", "Impayé", " " }));
        txtstatus2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                txtstatus2ItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel70)
                    .addComponent(jLabel68)
                    .addComponent(jLabel71, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtstatus2, 0, 210, Short.MAX_VALUE)
                    .addComponent(jTextField7)
                    .addComponent(jTextField8))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel68))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel70))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtstatus2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel71))
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jLabel198.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel198.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jMenu10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/add.PNG"))); // NOI18N
        jMenu10.setText("Ajouter");
        jMenu10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jMenu10MouseEntered(evt);
            }
        });
        jMenu10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu10ActionPerformed(evt);
            }
        });
        jMenuBar2.add(jMenu10);

        jMenu11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/modi.PNG"))); // NOI18N
        jMenu11.setText("Modifier");
        jMenu11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu11MouseClicked(evt);
            }
        });
        jMenuBar2.add(jMenu11);

        jMenu12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/delete.PNG"))); // NOI18N
        jMenu12.setText("Supprimer");
        jMenu12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu12MouseClicked(evt);
            }
        });
        jMenuBar2.add(jMenu12);

        jMenu13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/remove.PNG"))); // NOI18N
        jMenu13.setText("Fermer");
        jMenu13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu13MouseClicked(evt);
            }
        });
        jMenu13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu13ActionPerformed(evt);
            }
        });
        jMenuBar2.add(jMenu13);

        jFrame5.setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout jFrame5Layout = new javax.swing.GroupLayout(jFrame5.getContentPane());
        jFrame5.getContentPane().setLayout(jFrame5Layout);
        jFrame5Layout.setHorizontalGroup(
            jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrame5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrame5Layout.createSequentialGroup()
                        .addGroup(jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jFrame5Layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jFrame5Layout.createSequentialGroup()
                                .addGap(59, 59, 59)
                                .addComponent(jLabel198, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 85, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jFrame5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane18)))
                .addContainerGap())
        );
        jFrame5Layout.setVerticalGroup(
            jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrame5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jFrame5Layout.createSequentialGroup()
                        .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jFrame5Layout.createSequentialGroup()
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel198, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))))
        );

        jFrame10.setTitle("Statistique");
        jFrame10.setIconImage(logo.getImage());
        jFrame10.setLocation(new java.awt.Point(150, 40));
        jFrame10.setSize(new java.awt.Dimension(880, 610));

        jPanel39.setBackground(new java.awt.Color(255, 255, 255));

        jPanel40.setBackground(new java.awt.Color(247, 245, 245));
        jPanel40.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Patientes", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 0, 13))); // NOI18N

        jLabel30.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 153, 153));
        jLabel30.setText("Nombre de patientes :");

        jLabel31.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jLabel214.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel214.setForeground(new java.awt.Color(0, 153, 153));
        jLabel214.setText("Nombre de Patientes qui ont fait un Contrôle par Mois:");

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Année", "Nombre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable11.setShowGrid(true);
        jScrollPane42.setViewportView(jTable11);

        jLabel221.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel221.setForeground(new java.awt.Color(0, 153, 153));
        jLabel221.setText("Nombre de Patientes qui ont fait une Consultation par Mois:");

        jTable13.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Année", "Nombre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable13.setShowGrid(true);
        jScrollPane44.setViewportView(jTable13);

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane44, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel221)
                    .addComponent(jScrollPane42, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel214))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel214, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane42, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel221, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane44, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel41.setBackground(new java.awt.Color(247, 245, 245));
        jPanel41.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rendez-vous", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 0, 13))); // NOI18N

        jLabel210.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel210.setForeground(new java.awt.Color(0, 153, 153));
        jLabel210.setText("Nombre de rendez-vous par Mois:");

        jLabel211.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jLabel212.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel212.setForeground(new java.awt.Color(0, 153, 153));
        jLabel212.setText("Nombre de rendez-vous:");

        jTable9.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Année", "Nombre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable9.setShowGrid(true);
        jScrollPane40.setViewportView(jTable9);

        jLabel219.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel219.setForeground(new java.awt.Color(0, 153, 153));
        jLabel219.setText("Nombre de rendez-vous annulés :");

        jLabel220.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel41Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane40, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel210)
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addComponent(jLabel212)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel211, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addComponent(jLabel219)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel220, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel211, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel212, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel219, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel220, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel210, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane40, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel42.setBackground(new java.awt.Color(247, 245, 245));
        jPanel42.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Consultations", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 0, 13))); // NOI18N

        jLabel204.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel204.setForeground(new java.awt.Color(0, 153, 153));
        jLabel204.setText("Nombre de Consultations :");

        jLabel205.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel205.setForeground(new java.awt.Color(0, 153, 153));
        jLabel205.setText("Nombre de Consultations payées :");

        jLabel206.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel206.setForeground(new java.awt.Color(0, 153, 153));
        jLabel206.setText("Nombre de Consultations impayées:");

        jLabel207.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jLabel208.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jLabel209.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jTable10.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Année", "Nombre"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable10.setShowGrid(true);
        jScrollPane41.setViewportView(jTable10);

        jLabel213.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel213.setForeground(new java.awt.Color(0, 153, 153));
        jLabel213.setText("Nombre de Consultations par Mois:");

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel42Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel42Layout.createSequentialGroup()
                                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel205, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel206, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel209, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel208, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel42Layout.createSequentialGroup()
                                .addComponent(jLabel204)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel207, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(41, 41, 41))
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel213)
                            .addComponent(jScrollPane41, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel42Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel204, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel207, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel42Layout.createSequentialGroup()
                        .addComponent(jLabel205)
                        .addGap(6, 6, 6))
                    .addComponent(jLabel208, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel206)
                    .addComponent(jLabel209, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel213, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane41, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel45.setBackground(new java.awt.Color(247, 245, 245));
        jPanel45.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Documents", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI Semibold", 0, 13))); // NOI18N

        jLabel215.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel215.setForeground(new java.awt.Color(0, 153, 153));
        jLabel215.setText("Nombre de Certificats délivrées:");

        jLabel216.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel216.setForeground(new java.awt.Color(0, 153, 153));
        jLabel216.setText("Nombre d'ordonnances délivrées:");

        jLabel217.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        jLabel218.setFont(new java.awt.Font("Segoe UI Semibold", 0, 13)); // NOI18N

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addComponent(jLabel215)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel217, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addComponent(jLabel216)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel218, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel215, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel217, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel216, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel218, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel42, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel40, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(107, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jFrame10Layout = new javax.swing.GroupLayout(jFrame10.getContentPane());
        jFrame10.getContentPane().setLayout(jFrame10Layout);
        jFrame10Layout.setHorizontalGroup(
            jFrame10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame10Layout.setVerticalGroup(
            jFrame10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jFrame11.setTitle("Utilisateurs");
        jFrame11.setIconImage(logo.getImage());
        jFrame11.setLocation(new java.awt.Point(200, 150));
        jFrame11.setSize(new java.awt.Dimension(510, 310));

        jPanel43.setBackground(new java.awt.Color(255, 255, 255));

        jLabel32.setFont(new java.awt.Font("Segoe UI Semibold", 0, 17)); // NOI18N
        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/list.PNG"))); // NOI18N
        jLabel32.setText("La Liste d' Utilisateurs");

        jTable12.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane43.setViewportView(jTable12);

        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/ajou.PNG"))); // NOI18N
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/remove.PNG"))); // NOI18N
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jScrollPane43, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel32)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane43, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jFrame11Layout = new javax.swing.GroupLayout(jFrame11.getContentPane());
        jFrame11.getContentPane().setLayout(jFrame11Layout);
        jFrame11Layout.setHorizontalGroup(
            jFrame11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jFrame11Layout.createSequentialGroup()
                .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jFrame11Layout.setVerticalGroup(
            jFrame11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jFrame12.setTitle("Ajouter Utilisateur");
        jFrame12.setIconImage(logo.getImage());
        jFrame12.setLocation(new java.awt.Point(200, 150));
        jFrame12.setSize(new java.awt.Dimension(440, 260));

        jPanel44.setBackground(new java.awt.Color(255, 255, 255));

        jLabel38.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(0, 153, 153));
        jLabel38.setText("Nom d'utilisateur :");

        jLabel39.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(0, 153, 153));
        jLabel39.setText("Mot de passe :");

        jLabel40.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 153, 153));
        jLabel40.setText("Confirme mot de passe :");

        jTextField22.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/ajou.PNG"))); // NOI18N
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel44Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel40, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel44Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel44Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout jFrame12Layout = new javax.swing.GroupLayout(jFrame12.getContentPane());
        jFrame12.getContentPane().setLayout(jFrame12Layout);
        jFrame12Layout.setHorizontalGroup(
            jFrame12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jFrame12Layout.setVerticalGroup(
            jFrame12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Acceuil (Gestion_Cabinet)");
        setBackground(new java.awt.Color(255, 255, 255));
        setIconImage(logo.getImage());

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable1.setShowGrid(true);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 0, 51));
        jLabel10.setText("Liste Des Patientes");

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 0, 51));
        jLabel9.setText("Liste Des Rendez-vous");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable2.setShowGrid(true);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable2MouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 0, 51));
        jLabel8.setText("Liste Des Consultations");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable3.setShowGrid(true);
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable3MouseReleased(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        jButton1.setBackground(new java.awt.Color(255, 51, 0));
        jButton1.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Se Déconnecter");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel47.setBackground(new java.awt.Color(255, 255, 255));
        jLabel47.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(153, 153, 255));
        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel47.setText("chercher");

        jComboBox1.setBackground(new java.awt.Color(51, 204, 255));
        jComboBox1.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "nom", "cin", "mutuelle", "date", "address", " ", " ", " ", " " }));

        jTextField1.setBackground(new java.awt.Color(153, 255, 153));
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });

        jLabel45.setBackground(new java.awt.Color(255, 255, 255));
        jLabel45.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(153, 153, 255));
        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel45.setText("chercher");

        jComboBox2.setBackground(new java.awt.Color(51, 204, 255));
        jComboBox2.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "nom", "heure", "status", "date", "motif", "commentaire", " ", " " }));

        jTextField2.setBackground(new java.awt.Color(153, 255, 153));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField2KeyReleased(evt);
            }
        });

        jLabel46.setBackground(new java.awt.Color(255, 255, 255));
        jLabel46.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(153, 153, 255));
        jLabel46.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/find.PNG"))); // NOI18N
        jLabel46.setText("chercher");

        jComboBox3.setBackground(new java.awt.Color(51, 204, 255));
        jComboBox3.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "nom", "date", "motif", "diagnostic", "montant", "paiement", "reste", " ", " " }));

        jTextField3.setBackground(new java.awt.Color(153, 255, 153));
        jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField3KeyReleased(evt);
            }
        });

        date.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        date.setForeground(new java.awt.Color(51, 0, 0));

        hour.setFont(new java.awt.Font("Arial Narrow", 1, 16)); // NOI18N
        hour.setForeground(new java.awt.Color(51, 0, 0));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton1)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel17Layout.createSequentialGroup()
                                            .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel17Layout.createSequentialGroup()
                                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(60, 60, 60))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(hour, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(463, 463, 463))))
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(hour, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                            .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        menuBar.setBackground(new java.awt.Color(204, 204, 204));

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/acceu.PNG"))); // NOI18N
        jMenu1.setText("Acceuil");
        menuBar.add(jMenu1);

        fileMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/patient.PNG"))); // NOI18N
        fileMenu.setMnemonic('f');
        fileMenu.setText("Patientes");

        openMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/add.PNG"))); // NOI18N
        openMenuItem.setMnemonic('o');
        openMenuItem.setText("Nouvelle Patiente");
        openMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(openMenuItem);

        saveMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/modi.PNG"))); // NOI18N
        saveMenuItem.setMnemonic('s');
        saveMenuItem.setText("Modifier Patiente");
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveMenuItem);

        exitMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/delete.PNG"))); // NOI18N
        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Supprimer Patiente");
        exitMenuItem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitMenuItemMouseClicked(evt);
            }
        });
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/certi.PNG"))); // NOI18N
        jMenu3.setText("Créer Document");

        jMenuItem4.setText("Certificat Médical");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem4);

        jMenuItem6.setText("Compte Rendu");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem6);

        jMenuItem3.setText("Dossier Medical");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem3);

        jMenuItem7.setText("Facture");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem7);

        jMenuItem5.setText("Ordonnance Médicale");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem5);

        jMenuItem14.setText("Résumé");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem14);

        fileMenu.add(jMenu3);

        jMenu14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/open.PNG"))); // NOI18N
        jMenu14.setLabel("Pièces Jointes");

        jMenuItem8.setText("Certificat Médical");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem8);

        jMenuItem9.setText("Compte Rendu");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem9);

        jMenuItem10.setText("Dossier Médical");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem10);

        jMenuItem11.setText("Facture");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem11);

        jMenuItem12.setText("Ordonnance");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem12);

        jMenuItem13.setText("Résumé");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu14.add(jMenuItem13);

        fileMenu.add(jMenu14);

        menuBar.add(fileMenu);

        editMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/rendez.PNG"))); // NOI18N
        editMenu.setMnemonic('e');
        editMenu.setText("Rendez-vous");

        cutMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/add.PNG"))); // NOI18N
        cutMenuItem.setMnemonic('t');
        cutMenuItem.setText("Ajouter RDV");
        cutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cutMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(cutMenuItem);

        copyMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/modi.PNG"))); // NOI18N
        copyMenuItem.setMnemonic('y');
        copyMenuItem.setText("Modifier RDV");
        copyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(copyMenuItem);

        pasteMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/annul.PNG"))); // NOI18N
        pasteMenuItem.setMnemonic('p');
        pasteMenuItem.setText("Annuler RDV");
        pasteMenuItem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pasteMenuItemMouseClicked(evt);
            }
        });
        pasteMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasteMenuItemActionPerformed(evt);
            }
        });
        editMenu.add(pasteMenuItem);

        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/att.PNG"))); // NOI18N
        jMenuItem2.setText("Liste d'attente");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        editMenu.add(jMenuItem2);

        menuBar.add(editMenu);

        helpMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/cons.PNG"))); // NOI18N
        helpMenu.setMnemonic('h');
        helpMenu.setText("Consultations");

        contentsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/add.PNG"))); // NOI18N
        contentsMenuItem.setMnemonic('c');
        contentsMenuItem.setText("Ajouter Consultation");
        contentsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contentsMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(contentsMenuItem);

        aboutMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/modi.PNG"))); // NOI18N
        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("Modifier Consultation");
        aboutMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(aboutMenuItem);

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/delete.PNG"))); // NOI18N
        jMenuItem1.setText("Supprimer Consultation");
        jMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuItem1MouseClicked(evt);
            }
        });
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        helpMenu.add(jMenuItem1);

        menuBar.add(helpMenu);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/caisse.PNG"))); // NOI18N
        jMenu2.setText("Caisse");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        menuBar.add(jMenu2);

        jMenu9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/charge.PNG"))); // NOI18N
        jMenu9.setText("Charges");
        jMenu9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu9MouseClicked(evt);
            }
        });
        menuBar.add(jMenu9);

        jMenu15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/stati.PNG"))); // NOI18N
        jMenu15.setText("Statistiques");
        jMenu15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu15MouseClicked(evt);
            }
        });
        menuBar.add(jMenu15);

        jMenu16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gestion_cabinet/utili.PNG"))); // NOI18N
        jMenu16.setText("Utilisateurs");
        jMenu16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu16MouseClicked(evt);
            }
        });
        menuBar.add(jMenu16);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 1351, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cutMenuItemActionPerformed
        // TODO add your handling code here:
        jTextField43.setText("");
        txtheure.setSelectedItem("");
        txtstatus.setSelectedItem("");
        txtdate2.setText("");
        txtmotif.setText("");
        txtcom.setSelectedItem("Consultation");
        jDialog4.setVisible(true);
    }//GEN-LAST:event_cutMenuItemActionPerformed

    private void txtnomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomActionPerformed

    private void txtmutuelleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmutuelleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmutuelleActionPerformed

    private void txtprofessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprofessionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprofessionActionPerformed

    private void txtcinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcinActionPerformed

    private void txtsituationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsituationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsituationActionPerformed

    private void txtdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdateActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        try{
            Connect();
            pst = con.prepareStatement("insert into patient(nom,date,profession,address,mutuelle,situation,cin,phone)values(?,?,?,?,?,?,?,?)");
            pst.setString(1, txtnom.getText().toUpperCase());
            pst.setString(2, txtdate.getText().toUpperCase());
            pst.setString(3, txtprofession.getText().toUpperCase());
            pst.setString(4, txtaddress.getText().toUpperCase());
            pst.setString(5, txtmutuelle.getText().toUpperCase());
            pst.setString(6, txtsituation.getText().toUpperCase());
            pst.setString(7, txtcin.getText().toUpperCase());
            pst.setString(8, txtphone.getText().toUpperCase());
            pst.executeUpdate();
            con.close();
            table();
            JOptionPane.showMessageDialog(null, "Patiente ajoutée");
            jDialog1.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog1.setVisible(false);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        jDialog1.setVisible(false);
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void txtnom1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnom1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnom1ActionPerformed

    private void txtphone1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtphone1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtphone1ActionPerformed

    private void txtsituation1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsituation1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsituation1ActionPerformed

    private void txtmutuelle1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmutuelle1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmutuelle1ActionPerformed

    private void txtadress1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtadress1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtadress1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try{
            Connect();
            pst = con.prepareStatement("update patient set nom=?,date=?,profession=?,address=?,mutuelle=?,situation=?,cin=?,phone=? where code=?");
            int code = jTable1.getSelectedRow();
            String selectionner = (String)jTable1.getValueAt(code, 0);
            pst.setString(1, txtnom1.getText().toUpperCase());
            pst.setString(2, txtdate1.getText().toUpperCase());
            pst.setString(3, txtprofession1.getText().toUpperCase());
            pst.setString(4, txtadress1.getText().toUpperCase());
            pst.setString(5, txtmutuelle1.getText().toUpperCase());
            pst.setString(6, txtsituation1.getText().toUpperCase());
            pst.setString(7, txtcin1.getText().toUpperCase());
            pst.setString(8, txtphone1.getText().toUpperCase());
            pst.setString(9, selectionner);
            pst.executeUpdate();
            con.close();
            
            table();
            JOptionPane.showMessageDialog(null, "Patiente Modifiée");
            
            jDialog2.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog2.setVisible(false);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jDialog2.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseReleased
        // TODO add your handling code here:
        int select = jTable2.getSelectedRow();
        DefaultTableModel model1 = (DefaultTableModel)jTable2.getModel();
        Num = model1.getValueAt(select, 1).toString();
        jTextField45.setText(model1.getValueAt(select, 2).toString());
        txtheure1.setSelectedItem(model1.getValueAt(select, 3).toString());
        txtstatus1.setSelectedItem(model1.getValueAt(select, 4).toString().toLowerCase());
        txtdate3.setText(model1.getValueAt(select, 5).toString());
        txtmotif1.setText(model1.getValueAt(select, 6).toString());
        txtcom1.setSelectedItem(model1.getValueAt(select, 7).toString().toLowerCase());
    }//GEN-LAST:event_jTable2MouseReleased

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            try{
            Connect();
            pst = con.prepareStatement("delete from patient where code=?");
            int code = jTable1.getSelectedRow();
            String selectionner = (String)jTable1.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Patiente supprimée");
            table();
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        }
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMenuItemActionPerformed
        // TODO add your handling code here:
        jDialog2.setVisible(true);
    }//GEN-LAST:event_saveMenuItemActionPerformed

    private void openMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMenuItemActionPerformed
        // TODO add your handling code here:
         txtnom.setText("");
        date.setText("");
        txtprofession.setText("");
        txtaddress.setText("");
        txtmutuelle.setText("");
        txtsituation.setText("");
        txtcin.setText("");
        txtphone.setText("");
        
        jDialog1.setVisible(true);
    }//GEN-LAST:event_openMenuItemActionPerformed

    private void cancelButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton2ActionPerformed
       jDialog4.setVisible(false);
    }//GEN-LAST:event_cancelButton2ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        try{
            Connect2();
            pst = con.prepareStatement("insert into rendez(code,nom,heure,status,date,motif,commentaire) values(?,?,?,?,?,?,?)");
            pst.setString(1,Num);
            pst.setString(2, jTextField43.getText().toUpperCase());
            pst.setString(3, txtheure.getSelectedItem().toString().toUpperCase());
            pst.setString(4, txtstatus.getSelectedItem().toString().toUpperCase());
            pst.setString(5, txtdate2.getText().toUpperCase());
            pst.setString(6, txtmotif.getText().toUpperCase());
            pst.setString(7, txtcom.getSelectedItem().toString().toUpperCase());
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Rendez-vous ajouté");
            table2();
            jDialog4.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog4.setVisible(false);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        jDialog5.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        if("terminé".equals(txtstatus1.getSelectedItem().toString().toLowerCase())){
            try{
            Connect3();
            pst = con.prepareStatement("insert into consultation(code,nom,date,motif,diagnostic)values(?,?,?,?,?)");
            pst.setString(1, Num);
            pst.setString(2, jTextField45.getText().toUpperCase());
            pst.setString(3, txtdate3.getText().toUpperCase());
            pst.setString(4, txtmotif1.getText().toUpperCase());
            pst.setString(5, txtcom1.getSelectedItem().toString().toUpperCase());
            pst.executeUpdate();
            con.close();
            jDialog5.setVisible(false);
            JOptionPane.showMessageDialog(null, "Consultation ajoutée");
            table3();
            }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            }
            try{
            Connect2();
            pst = con.prepareStatement("delete from rendez where num=?");
            int code = jTable2.getSelectedRow();
            String selectionner = (String)jTable2.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            table2();
            }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            }
        }else{
        try{
            Connect2();
            pst = con.prepareStatement("update rendez set code=?,nom=?,heure=?,status=?,date=?,motif=?,commentaire=? where num=?");
            int code = jTable2.getSelectedRow();
            String selectionner = (String)jTable2.getValueAt(code, 0);
            pst.setString(1, Num);
            pst.setString(2, jTextField45.getText().toUpperCase());
            pst.setString(3, txtheure1.getSelectedItem().toString().toUpperCase());
            pst.setString(4, txtstatus1.getSelectedItem().toString().toUpperCase());
            pst.setString(5, txtdate3.getText().toUpperCase());
            pst.setString(6, txtmotif1.getText().toUpperCase());
            pst.setString(7, txtcom1.getSelectedItem().toString().toUpperCase());
            pst.setString(8, selectionner);
            pst.executeUpdate();
            con.close();
            
            table2();
            JOptionPane.showMessageDialog(null, "Rendez-vous Modifié");
            
            jDialog5.setVisible(false);
            }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog5.setVisible(false);
            }
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void copyMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyMenuItemActionPerformed
        // TODO add your handling code here:
        
        jDialog5.setVisible(true);
    }//GEN-LAST:event_copyMenuItemActionPerformed

    private void pasteMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasteMenuItemActionPerformed
        // TODO add your handling code here:
       int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
             try{
            Connect2();
            pst = con.prepareStatement("update rendez set status=? where code=?");
            int code = jTable2.getSelectedRow();
            String selectionner = (String)jTable2.getValueAt(code, 0);
            pst.setString(1, "Annulé");
            pst.setString(2, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Rendez-vous Annulé");
            table2();
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        }
    }//GEN-LAST:event_pasteMenuItemActionPerformed

    private void txtmotif2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmotif2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmotif2ActionPerformed

    private void txtdate4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdate4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdate4ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        try{
            Connect3();
            pst = con.prepareStatement("insert into consultation(code,nom,date,motif,diagnostic) values(?,?,?,?,?)");
            pst.setString(1, Num);
            pst.setString(2, jTextField44.getText().toUpperCase());
            pst.setString(3, txtdate4.getText().toUpperCase());
            pst.setString(4, txtmotif2.getText().toUpperCase());
            pst.setString(5, txtdiagno2.getText().toUpperCase());
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Consultation ajoutée");
            table3();
            jDialog7.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog7.setVisible(false);
        }
        
    }//GEN-LAST:event_jButton10ActionPerformed

    private void contentsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contentsMenuItemActionPerformed
        // TODO add your handling code here:
        jTextField44.setText("");
        txtdate4.setText("");
        txtmotif2.setText("");
        txtdiagno2.setText("");
        jDialog7.setVisible(true);
    }//GEN-LAST:event_contentsMenuItemActionPerformed

    private void cancelButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton4ActionPerformed
        // TODO add your handling code here:
        jDialog7.setVisible(false);
    }//GEN-LAST:event_cancelButton4ActionPerformed

    private void txtmotif3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmotif3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmotif3ActionPerformed

    private void txtdate5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdate5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdate5ActionPerformed

    private void cancelButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButton5ActionPerformed
        // TODO add your handling code here:
        jDialog8.setVisible(false);
    }//GEN-LAST:event_cancelButton5ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        try{
            Connect3();
            pst = con.prepareStatement("update consultation set code=?,nom=?,date=?,motif=?,diagnostic=? where num=? ");
            int code = jTable3.getSelectedRow();
            String selectionner = (String)jTable3.getValueAt(code, 0);
            pst.setString(1, Num);
            pst.setString(2, jTextField45.getText().toUpperCase());
            pst.setString(3, txtdate5.getText().toUpperCase());
            pst.setString(4, txtmotif3.getText().toUpperCase());
            pst.setString(5, txtdiagno3.getText().toUpperCase());
            pst.setString(6, selectionner);
            pst.executeUpdate();
            con.close();
            
            table3();
            JOptionPane.showMessageDialog(null, "Consultation Modifiée");
            
            jDialog8.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jDialog8.setVisible(false);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void aboutMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutMenuItemActionPerformed
        // TODO add your handling code here:
        jDialog8.setVisible(true);
    }//GEN-LAST:event_aboutMenuItemActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            try{
            Connect3();
            pst = con.prepareStatement("delete from consultation where num=?");
            int code = jTable3.getSelectedRow();
            String selectionner = (String)jTable3.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Consultation supprimée");
            table3();
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }}
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        table4();
        jDialog10.setVisible(true);
        
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void ModifierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModifierActionPerformed
        // TODO add your handling code here:
        jDialog2.setVisible(true);
    }//GEN-LAST:event_ModifierActionPerformed

    private void SupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupprimerActionPerformed
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            try{
            Connect();
            pst = con.prepareStatement("delete from patient where code=?");
            int code = jTable1.getSelectedRow();
            String selectionner = (String)jTable1.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            
            Connect2();
            pst = con.prepareStatement("delete from rendez where code=?");
            String selectionner1 = (String)jTable1.getValueAt(code, 0);
            pst.setString(1, selectionner1);
            pst.executeUpdate();
            con.close();
            table();
            table2();
            JOptionPane.showMessageDialog(null, "Patiente supprimée");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        }
    }//GEN-LAST:event_SupprimerActionPerformed

    private void Modifier1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Modifier1ActionPerformed
        // TODO add your handling code here:
        
        jDialog5.setVisible(true);
    }//GEN-LAST:event_Modifier1ActionPerformed

    private void Supprimer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Supprimer1ActionPerformed
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment Annuler");
        if(input == 0){
             try{
            Connect2();
            pst = con.prepareStatement("update rendez set status=? where num=?");
            int code = jTable2.getSelectedRow();
            String selectionner = (String)jTable2.getValueAt(code, 0);
            pst.setString(1, "Annulé");
            pst.setString(2, selectionner);
            pst.executeUpdate();
            con.close();
            table2();
            JOptionPane.showMessageDialog(null, "Rendez-vous Annulé");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        }
    }//GEN-LAST:event_Supprimer1ActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        jPopupMenu2.show(this, evt.getXOnScreen(), evt.getYOnScreen());
    }//GEN-LAST:event_jTable2MouseClicked

    private void Modifier2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Modifier2ActionPerformed
        // TODO add your handling code here:
        jDialog8.setVisible(true);
    }//GEN-LAST:event_Modifier2ActionPerformed

    private void Supprimer2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Supprimer2ActionPerformed
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            try{
            Connect3();
            pst = con.prepareStatement("delete from consultation where num=?");
            int code = jTable3.getSelectedRow();
            String selectionner = (String)jTable3.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            table3();
            JOptionPane.showMessageDialog(null, "Consultation supprimée");
           
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }}
    }//GEN-LAST:event_Supprimer2ActionPerformed

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased
        // TODO add your handling code here:
        String value = jTextField1.getText().toUpperCase();
        String value1 = jComboBox1.getSelectedItem().toString();
        String []patient = {"CODE","NOM","DATE_NAISSANCE","PROFESSION","ADRESSE","MUTUELLE","SITUATION_FAMILIALE","CIN","TELEPHONE"};
        String []montrer = new String[10];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from patient where "+value1+" like '"+value+"%'";
        try{
            Connect();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("date");
                montrer[3] = rs.getString("profession");
                montrer[4] = rs.getString("address");
                montrer[5] = rs.getString("mutuelle");
                montrer[6] = rs.getString("situation");
                montrer[7] = rs.getString("cin");
                montrer[8] = rs.getString("phone");
                model.addRow(montrer);
            }
            jTable1.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField1KeyReleased

    private void jTextField2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyReleased
        // TODO add your handling code here:
        String value = jTextField2.getText().toUpperCase();
        String value1 = jComboBox2.getSelectedItem().toString();
        String []patient = {"CODE","PATIENT","HEURE","STATUS","DATE","MOTIF","TYPE"};        
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from rendez where "+value1+" like '"+value+"%'";
        try{
            Connect2();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("heure");
                montrer[3] = rs.getString("status");
                montrer[4] = rs.getString("date");
                montrer[5] = rs.getString("motif");
                montrer[6] = rs.getString("commentaire");
                model.addRow(montrer);
            }
            jTable2.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField2KeyReleased

    private void jTextField3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyReleased
        // TODO add your handling code here:
        String value = jTextField3.getText().toUpperCase();
        String value1 = jComboBox3.getSelectedItem().toString();
        String []patient = {"CODE","PATIENT","DATE","MOTIF","DIAGNOSTIC","MONTANT","PAIEMENT","RESTE A PAYE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from consultation where "+value1+" like '"+value+"%'";
        try{
            Connect3();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("date");
                montrer[3] = rs.getString("motif");
                montrer[4] = rs.getString("diagnostic");
                montrer[5] = rs.getString("montant");
                montrer[6] = rs.getString("paiement");
                montrer[7] = rs.getString("reste");
                model.addRow(montrer);
            }
            jTable3.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField3KeyReleased

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        CabinetApplication.super.dispose();
                 login me = new login();
                 me.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Certificats\\Certificat Médical.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Certificats\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Ordonnances\\Ordonnance.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Ordonnances\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField4KeyReleased
        // TODO add your handling code here:
        String value = jTextField4.getText().toUpperCase();
        String []patient = {"CODE","NOM","DATE_NAISSANCE","PROFESSION","ADRESSE","MUTUELLE","SITUATION_FAMILIALE","CIN","TELEPHONE"};
        String []montrer = new String[10];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from patient where nom like '"+value+"%'";
        try{
            Connect();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("nom");
                montrer[2] = rs.getString("date");
                montrer[3] = rs.getString("profession");
                montrer[4] = rs.getString("address");
                montrer[5] = rs.getString("mutuelle");
                montrer[6] = rs.getString("situation");
                montrer[7] = rs.getString("cin");
                montrer[8] = rs.getString("phone");
                model.addRow(montrer);
            }
            jTable5.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField4KeyReleased

    private void jTable5MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseReleased
        // TODO add your handling code here:
        int select = jTable5.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
        jcode.setText(model.getValueAt(select, 0).toString());
        jnom.setText(model.getValueAt(select, 1).toString());
        jphone.setText(model.getValueAt(select, 8).toString());
    }//GEN-LAST:event_jTable5MouseReleased

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(false);
        jcode.setText("");
        jnom.setText("");
        jphone.setText("");
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(false);
        
        int select = jTable5.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
        jcode.setText(model.getValueAt(select, 0).toString());
        Num = model.getValueAt(select, 0).toString();
        jnom.setText(model.getValueAt(select, 1).toString());
        jTextField43.setText(model.getValueAt(select, 1).toString());
        jTextField44.setText(model.getValueAt(select, 1).toString());
        jTextField45.setText(model.getValueAt(select, 1).toString());
        jTextField46.setText(model.getValueAt(select, 1).toString());
        jphone.setText(model.getValueAt(select, 8).toString());
        
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
        table();
        jDialog13.setVisible(true);
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jMenu7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu7ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jMenu7ActionPerformed

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu4MouseClicked
        // TODO add your handling code here:
         try{
            Connect4();
            pst = con.prepareStatement("insert into Reglements(code,patient,date,actes,montant,paiement,reste) values(?,?,?,?,?,?,?)");
            pst.setString(1, Num1); 
            pst.setString(2, jnom.getText().toUpperCase());
            pst.setString(3, jFormattedTextField1.getText().toUpperCase());
            pst.setString(4, jTextArea4.getText().toUpperCase());
            pst.setString(5, txtmotif8.getText().toUpperCase());
            pst.setString(6, txtmotif10.getText().toUpperCase());
            pst.setString(7, txtmotif9.getText().toUpperCase());
            pst.executeUpdate();
            con.close();
            table5();
            JOptionPane.showMessageDialog(null, "Règlement ajouté");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            
        }
         
        String sql = "select SUM(paiement) from Reglements ";
         try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel65.setText("Montant Total : "+rs.getString("SUM(paiement)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenu4MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        jcode.setText("");
        jnom.setText("");
        jphone.setText("");
        txtmotif9.setText("");
        txtmotif10.setText("");
        txtmotif8.setText("");
        jTextArea4.setText("");
        jFormattedTextField1.setText("");
        table5();
        jFrame3.setVisible(true);
        String sql = "select SUM(paiement) from Reglements ";
        try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel65.setText("Montant Total : "+rs.getString("SUM(paiement)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
            
    }//GEN-LAST:event_jMenu2MouseClicked

    private void jMenu7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu7MouseClicked
        // TODO add your handling code here:
        jFrame3.setVisible(false);
    }//GEN-LAST:event_jMenu7MouseClicked

    private void jTextField5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField5KeyReleased
        // TODO add your handling code here:
        String value = jTextField5.getText().toUpperCase();
        String []patient = {"NUM_REGLEMENT","CODE","PATIENT","DATE","ACTES_MEDICAUX","MONTANT_TOTALE","PAIEMENT","RESTE A PAYE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from Reglements where patient like '"+value+"%'";
        try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("num");
                montrer[1] = rs.getString("code");
                montrer[2] = rs.getString("patient");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("actes");
                montrer[5] = rs.getString("montant");
                montrer[6] = rs.getString("paiement");
                montrer[7] = rs.getString("reste");
                model.addRow(montrer);
            }
            jTable6.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField5KeyReleased

    private void jTextField6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField6KeyReleased
        // TODO add your handling code here:
        String value = jTextField6.getText().toUpperCase();
        String []patient = {"NUM_REGLEMENT","CODE","PATIENT","DATE","ACTES_MEDICAUX","MONTANT_TOTALE","PAIEMENT","RESTE A PAYE"};
        String []montrer = new String[8];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from Reglements where date like '"+value+"%'";
        try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("num");
                montrer[1] = rs.getString("code");
                montrer[2] = rs.getString("patient");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("actes");
                montrer[5] = rs.getString("montant");
                montrer[6] = rs.getString("paiement");
                montrer[7] = rs.getString("reste");
                model.addRow(montrer);
            }
            jTable6.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField6KeyReleased

    private void jMenu4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu4MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu4MouseEntered

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        try{
            Connect4();
            pst = con.prepareStatement("update Reglements set num=?,patient=?,date=?,actes=?,montant=?,paiement=?,reste=? where code=?");
            int code = jTable6.getSelectedRow();
            String selectionner = (String)jTable6.getValueAt(code, 0);
            pst.setString(1, Num1);
            pst.setString(2, jnom.getText().toUpperCase());
            pst.setString(3, jFormattedTextField1.getText().toUpperCase());
            pst.setString(4, jTextArea4.getText().toUpperCase());
            pst.setString(5, txtmotif8.getText().toUpperCase());
            pst.setString(6, txtmotif10.getText().toUpperCase());
            pst.setString(7, txtmotif9.getText().toUpperCase());
            pst.setString(8, selectionner);
            pst.executeUpdate();
            pst.executeUpdate();
            con.close();
            table5();
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        String sql = "select SUM(paiement) from Reglements ";
         try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel65.setText("Montant Total : "+rs.getString("SUM(paiement)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenu5MouseClicked

    private void jMenu6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu6MouseClicked
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            
            try{
            Connect4();
            pst = con.prepareStatement("delete from Reglements where num=?");
            int code = jTable6.getSelectedRow();
            String selectionner = (String)jTable6.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Reglement supprimé");
            table5();
            
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Operation echouée ");
            }
            
            String sql = "select SUM(paiement) from Reglements ";
         try{
            Connect4();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel65.setText("Montant Total : "+rs.getString("SUM(paiement)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        }
    }//GEN-LAST:event_jMenu6MouseClicked

    private void jTable6MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseReleased
        // TODO add your handling code here:
        int select = jTable6.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable6.getModel();
        Num1 = model.getValueAt(select, 1).toString();
        jnom.setText(model.getValueAt(select, 2).toString());
        jFormattedTextField1.setText(model.getValueAt(select, 3).toString());
        jTextArea4.setText(model.getValueAt(select, 4).toString());
        txtmotif8.setText(model.getValueAt(select, 5).toString());
        txtmotif10.setText(model.getValueAt(select, 6).toString());
        txtmotif9.setText(model.getValueAt(select, 7).toString());
    }//GEN-LAST:event_jTable6MouseReleased

    private void exitMenuItemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitMenuItemMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_exitMenuItemMouseClicked

    private void pasteMenuItemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pasteMenuItemMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_pasteMenuItemMouseClicked

    private void jMenuItem1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuItem1MouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jMenuItem1MouseClicked

    private void jBut7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut7ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut7.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut7ActionPerformed

    private void jBut1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut1ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut1.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut1ActionPerformed

    private void jBut2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut2ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut2.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut2ActionPerformed

    private void jBut3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut3ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut3.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut3ActionPerformed

    private void jBut4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut4ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut4.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut4ActionPerformed

    private void jBut5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut5ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut5.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut5ActionPerformed

    private void jBut6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut6ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut6.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut6ActionPerformed

    private void jBut8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut8ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut8.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut8ActionPerformed

    private void jBut9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut9ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut9.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut9ActionPerformed

    private void jBut10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut10ActionPerformed
        // TODO add your handling code here:
        String enter = Display.getText()+jBut10.getActionCommand();
        Display.setText(enter);
    }//GEN-LAST:event_jBut10ActionPerformed

    private void jBut13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut13ActionPerformed
        // TODO add your handling code here:
        Display.setText("");
    }//GEN-LAST:event_jBut13ActionPerformed

    private void jBut11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut11ActionPerformed
        // TODO add your handling code here:
        first = Double.parseDouble(Display.getText());
        Display.setText("");
        operation = "+";
    }//GEN-LAST:event_jBut11ActionPerformed

    private void jBut12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut12ActionPerformed
        // TODO add your handling code here:
        first = Double.parseDouble(Display.getText());
        Display.setText("");
        operation = "-";
    }//GEN-LAST:event_jBut12ActionPerformed

    private void jBut15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut15ActionPerformed
        // TODO add your handling code here:
        first = Double.parseDouble(Display.getText());
        Display.setText("");
        operation = "*";
    }//GEN-LAST:event_jBut15ActionPerformed

    private void jBut16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut16ActionPerformed
        // TODO add your handling code here:
        first = Double.parseDouble(Display.getText());
        Display.setText("");
        operation = "/";
    }//GEN-LAST:event_jBut16ActionPerformed

    private void jBut14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut14ActionPerformed
        // TODO add your handling code here:
        String answer;
        seconde = Double.parseDouble(Display.getText());
        if(operation == "+"){
            result = first + seconde;
            answer = String.format("%.0f", result);
            Display.setText(answer);
        }else if(operation == "-"){
            result = first - seconde;
            answer = String.format("%.0f", result);
            Display.setText(answer);
        }else if(operation == "*"){
            result = first*seconde;
            answer = String.format("%.0f", result);
            Display.setText(answer);
        }else if(operation == "/"){
            result = first/seconde;
            answer = String.format("%.0f", result);
            Display.setText(answer);
        }
    }//GEN-LAST:event_jBut14ActionPerformed

    private void jMenu8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu8MouseClicked
        // TODO add your handling code here:
        jFrame4.setVisible(true);
    }//GEN-LAST:event_jMenu8MouseClicked

    private void jMenu10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu10MouseClicked
        // TODO add your handling code here:
        try{
            Connect5();
            pst = con.prepareStatement("insert into charge(type,montant,date,etat,observation) values(?,?,?,?,?)");
            pst.setString(1, jcode1.getText().toUpperCase());
            pst.setString(2, jFormattedTextField3.getText().toUpperCase());
            pst.setString(3, jFormattedTextField2.getText().toUpperCase());
            pst.setString(4, txtstatus3.getSelectedItem().toString().toUpperCase());
            pst.setString(5, jTextArea5.getText().toUpperCase());
            pst.executeUpdate();
            con.close();
            table6();
            JOptionPane.showMessageDialog(null, "Charge ajoutée");
            
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            
        }
        String sql = "select SUM(montant) from charge ";
         try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel198.setText("Montant Total : "+rs.getString("SUM(montant)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenu10MouseClicked

    private void jMenu10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu10MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu10MouseEntered

    private void jMenu10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu10ActionPerformed

    private void jMenu11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu11MouseClicked
        // TODO add your handling code here:
        try{
            Connect5();
            pst = con.prepareStatement("update charge set type=?,montant=?,date=?,etat=?,observation=? where code=?");
            int code = jTable7.getSelectedRow();
            String selectionner = (String)jTable7.getValueAt(code, 0);
            pst.setString(1, jcode1.getText().toUpperCase());
            pst.setString(2, jFormattedTextField3.getText().toUpperCase());
            pst.setString(3, jFormattedTextField2.getText().toUpperCase());
            pst.setString(4, txtstatus3.getSelectedItem().toString().toUpperCase());
            pst.setString(5, jTextArea5.getText().toUpperCase());
            pst.setString(6, selectionner);
            pst.executeUpdate();
            pst.executeUpdate();
            con.close();
            table6();
            JOptionPane.showMessageDialog(null, "Charge modifiée");
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenu11MouseClicked

    private void jMenu12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu12MouseClicked
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            
            try{
            Connect5();
            pst = con.prepareStatement("delete from charge where code=?");
            int code = jTable7.getSelectedRow();
            String selectionner = (String)jTable7.getValueAt(code, 0);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Charge supprimée");
            table5();
            
            }catch(Exception e){
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Operation echouée ");
            }
        }    
    }//GEN-LAST:event_jMenu12MouseClicked

    private void jMenu13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu13MouseClicked
        // TODO add your handling code here:
        jFrame5.setVisible(false);
    }//GEN-LAST:event_jMenu13MouseClicked

    private void jMenu13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu13ActionPerformed

    private void jTextField7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField7KeyReleased
        // TODO add your handling code here:
        String value = jTextField7.getText().toUpperCase();
        String []patient = {"CODE","TYPE","MONTANT","DATE","ETAT","OBSERVATION"};
        String []montrer = new String[6];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from charge where type like '"+value+"%'";
        try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("type");
                montrer[2] = rs.getString("montant");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("etat");
                montrer[5] = rs.getString("observation");
                model.addRow(montrer);
            }
            jTable7.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField7KeyReleased

    private void jTextField8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField8KeyReleased
        // TODO add your handling code here:
        String value = jTextField8.getText().toUpperCase();
        String []patient = {"CODE","TYPE","MONTANT","DATE","ETAT","OBSERVATION"};
        String []montrer = new String[6];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from charge where date like '"+value+"%'";
        try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("type");
                montrer[2] = rs.getString("montant");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("etat");
                montrer[5] = rs.getString("observation");
                model.addRow(montrer);
            }
            jTable7.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jTextField8KeyReleased

    private void jTable7MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7MouseReleased
        // TODO add your handling code here:
        int select = jTable7.getSelectedRow();
        DefaultTableModel model1 = (DefaultTableModel)jTable7.getModel();
        jcode1.setText(model1.getValueAt(select, 1).toString());
        jFormattedTextField3.setText(model1.getValueAt(select, 2).toString());
        jFormattedTextField2.setText(model1.getValueAt(select, 3).toString());
        txtstatus3.setSelectedItem(model1.getValueAt(select, 4).toString().toLowerCase());
        jTextArea5.setText(model1.getValueAt(select, 5).toString());
    }//GEN-LAST:event_jTable7MouseReleased

    private void txtstatus2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_txtstatus2ItemStateChanged
        // TODO add your handling code here:
        String value = txtstatus2.getSelectedItem().toString().toUpperCase();
        String []patient = {"CODE","TYPE","MONTANT","DATE","ETAT","OBSERVATION"};
        String []montrer = new String[6];
        DefaultTableModel model = new DefaultTableModel(null,patient);
        String sql = "select * from charge where etat like '"+value+"%'";
        try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()){
                montrer[0] = rs.getString("code");
                montrer[1] = rs.getString("type");
                montrer[2] = rs.getString("montant");
                montrer[3] = rs.getString("date");
                montrer[4] = rs.getString("etat");
                montrer[5] = rs.getString("observation");
                model.addRow(montrer);
            }
            jTable7.setModel(model);
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtstatus2ItemStateChanged

    private void jMenu9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu9MouseClicked
        // TODO add your handling code here:
        String sql = "select SUM(montant) from charge ";
         try{
            Connect5();
            Statement st = con.createStatement();
            rs = st.executeQuery(sql);
            jLabel198.setText("Montant Total : "+rs.getString("SUM(montant)"));
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        table6();
        jFrame5.setVisible(true);
    }//GEN-LAST:event_jMenu9MouseClicked

    private void txtaddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtaddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtaddressActionPerformed

    private void txtphoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtphoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtphoneActionPerformed

    private void txtdate1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdate1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtdate1ActionPerformed

    private void txtprofession1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprofession1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprofession1ActionPerformed

    private void txtcin1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcin1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcin1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Dossiers Medicals\\Dossier Medical1.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Dossiers Medicals\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        
        
        /* jTextArea9.setText("");
        jTextArea8.setText("");
        jTextArea7.setText("");
        jTextArea6.setText("");
        
        jTextField23.setText("");
        jTextField24.setText("");
        jTextField25.setText("");
        jTextField26.setText("");
        jTextField27.setText("");
        jTextField28.setText("");
        jTextField29.setText("");
        jTextField30.setText("");
        jTextField31.setText("");
        jTextField32.setText("");
        jTextField33.setText("");
        jTextField34.setText("");
        jTextField35.setText("");
        jTextField36.setText("");
        jTextField37.setText("");
        jTextField38.setText("");
        jTextField39.setText("");
        jTextField40.setText("");
        jTextField41.setText("");
        jTextField42.setText("");
        jTextArea10.setText("");
        jTextArea10.setText("");
        jTextField53.setText("");
        jTextField54.setText("");
        jTextField55.setText("");
        jTextField56.setText("");
        jTextField57.setText("");
        jTextField58.setText("");
        jTextField59.setText("");
        jTextField60.setText("");
        
        
        
        
        jFrame6.setVisible(true);*/
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Comptes Rendus\\Compte Rendu.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Comptes Rendus\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Factures\\Facture.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Factures\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Certificats\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Comptes Rendus\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Dossiers Medicals\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Factures\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Ordonnances\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model1 = (DefaultTableModel)jTable1.getModel();
        
        txtnom1.setText(model1.getValueAt(select, 1).toString());
        txtdate1.setText(model1.getValueAt(select, 2).toString());
        txtprofession1.setText(model1.getValueAt(select, 3).toString());
        txtadress1.setText(model1.getValueAt(select, 4).toString());
        txtmutuelle1.setText(model1.getValueAt(select, 5).toString());
        txtsituation1.setText(model1.getValueAt(select, 6).toString());
        txtcin1.setText(model1.getValueAt(select, 7).toString());
        txtphone1.setText(model1.getValueAt(select, 8).toString());
    }//GEN-LAST:event_jTable1MouseReleased

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        jPopupMenu1.show(this, evt.getXOnScreen(), evt.getYOnScreen());
    }//GEN-LAST:event_jTable1MouseClicked

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        try{
            File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Résumés\\"+model.getValueAt(select, 1).toString()+".docx");
            if(file.exists()){
                if(Desktop.isDesktopSupported()){
                Desktop.getDesktop().open(file);
                }else{
                    JOptionPane.showMessageDialog(this, "Non supporté");
                }
            }else{
                JOptionPane.showMessageDialog(this, "Le Fichier n'existe pas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void jTable3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseReleased
        // TODO add your handling code here:
        int select = jTable3.getSelectedRow();
        DefaultTableModel model1 = (DefaultTableModel)jTable3.getModel();
        jTextField46.setText(model1.getValueAt(select, 2).toString());
        txtdate5.setText(model1.getValueAt(select, 3).toString());
        txtmotif3.setText(model1.getValueAt(select, 4).toString());
        txtdiagno3.setText(model1.getValueAt(select, 5).toString());
    }//GEN-LAST:event_jTable3MouseReleased

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        jPopupMenu3.show(this, evt.getXOnScreen(), evt.getYOnScreen());
    }//GEN-LAST:event_jTable3MouseClicked

    private void jMenu15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu15MouseClicked
        // TODO add your handling code here:
        int j=0,k=0,l=0,w=0;
        jLabel31.setText(String.valueOf(jTable1.getRowCount()));
        jLabel211.setText(String.valueOf(jTable2.getRowCount()));
        jLabel207.setText(String.valueOf(jTable3.getRowCount()));
        for(int i=0 ; i<jTable2.getRowCount(); i++){
            if("annulé".equals(jTable2.getValueAt(i,3 ).toString().toLowerCase())){
                j++;
            }
        }
        for(int i=0 ; i<jTable6.getRowCount(); i++){
            if((Integer.parseInt(jTable6.getValueAt(i,6 ).toString())) == w){
                k++;
            }
        }
        for(int i=0 ; i<jTable6.getRowCount(); i++){
            if((Integer.parseInt(jTable6.getValueAt(i,6 ).toString())) != w){
                l++;
            }
        }
        jLabel208.setText(String.valueOf(k));
        jLabel209.setText(String.valueOf(l));
        jLabel220.setText(String.valueOf(j));
        jLabel217.setText(String.valueOf(new File(System.getProperty("user.dir")+File.separator+"Documents\\Certificats").list().length));
        table11();
        jLabel218.setText(String.valueOf(new File(System.getProperty("user.dir")+File.separator+"Documents\\Ordonnances").list().length));
        table12();
        table13();
        table11();
        table10();
        table9();
        jFrame10.setVisible(true);
    }//GEN-LAST:event_jMenu15MouseClicked

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        int input = JOptionPane.showConfirmDialog(null, "Vous voulez vraiment supprimer");
        if(input == 0){
            try{
            Connect12();
            pst = con.prepareStatement("delete from login where mdp=?");
            int code = jTable12.getSelectedRow();
            String selectionner = (String)jTable12.getValueAt(code, 1);
            pst.setString(1, selectionner);
            pst.executeUpdate();
            con.close();
            JOptionPane.showMessageDialog(null, "Utilisateur supprimé");
            table12();
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
        }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jMenu16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu16MouseClicked
        // TODO add your handling code here:
        table12();
        jFrame11.setVisible(true);
    }//GEN-LAST:event_jMenu16MouseClicked

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
         try{
            Connect12();
            pst = con.prepareStatement("insert into login(nom,mdp) values(?,?)");
            pst.setString(1, jTextField22.getText());
            pst.setString(2, jPasswordField1.getText());
            pst.executeUpdate();
            con.close();
            table12();
            JOptionPane.showMessageDialog(null, "Utilisateur ajouté");
            jFrame12.setVisible(false);
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
            jFrame12.setVisible(false);
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
        jFrame12.setVisible(true);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(true);
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(true);
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(true);
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        // TODO add your handling code here:
        jDialog13.setVisible(true);
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem14ActionPerformed
        // TODO add your handling code here:
        int select = jTable1.getSelectedRow();
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        File file = new File(System.getProperty("user.dir")+File.separator+"Documents\\Résumés\\Résumé.docx");
        File newfile = new File(System.getProperty("user.dir")+File.separator+"Documents\\Résumés\\"
               +model.getValueAt(select, 1).toString()+".docx");
        try{
         if(!newfile.exists()){
         Files.copy(file.toPath(), newfile.toPath());
         }else{
            JOptionPane.showMessageDialog(null, "Fichier  Dèjas existe ");
         }
         Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+newfile.getPath());
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Operation echouée ");
        }
    }//GEN-LAST:event_jMenuItem14ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CabinetApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CabinetApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CabinetApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CabinetApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CabinetApplication().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Display;
    private javax.swing.JMenuItem Modifier;
    private javax.swing.JMenuItem Modifier1;
    private javax.swing.JMenuItem Modifier2;
    private javax.swing.JMenuItem Supprimer;
    private javax.swing.JMenuItem Supprimer1;
    private javax.swing.JMenuItem Supprimer2;
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton cancelButton2;
    private javax.swing.JButton cancelButton4;
    private javax.swing.JButton cancelButton5;
    private javax.swing.JMenuItem contentsMenuItem;
    private javax.swing.JMenuItem copyMenuItem;
    private javax.swing.JMenuItem cutMenuItem;
    private javax.swing.JLabel date;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JLabel hour;
    private javax.swing.JButton jBut1;
    private javax.swing.JButton jBut10;
    private javax.swing.JButton jBut11;
    private javax.swing.JButton jBut12;
    private javax.swing.JButton jBut13;
    private javax.swing.JButton jBut14;
    private javax.swing.JButton jBut15;
    private javax.swing.JButton jBut16;
    private javax.swing.JButton jBut2;
    private javax.swing.JButton jBut3;
    private javax.swing.JButton jBut4;
    private javax.swing.JButton jBut5;
    private javax.swing.JButton jBut6;
    private javax.swing.JButton jBut7;
    private javax.swing.JButton jBut8;
    private javax.swing.JButton jBut9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog10;
    private javax.swing.JDialog jDialog13;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JDialog jDialog4;
    private javax.swing.JDialog jDialog5;
    private javax.swing.JDialog jDialog7;
    private javax.swing.JDialog jDialog8;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JFormattedTextField jFormattedTextField2;
    private javax.swing.JFormattedTextField jFormattedTextField3;
    private javax.swing.JFrame jFrame10;
    private javax.swing.JFrame jFrame11;
    private javax.swing.JFrame jFrame12;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JFrame jFrame4;
    private javax.swing.JFrame jFrame5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu11;
    private javax.swing.JMenu jMenu12;
    private javax.swing.JMenu jMenu13;
    private javax.swing.JMenu jMenu14;
    private javax.swing.JMenu jMenu15;
    private javax.swing.JMenu jMenu16;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem14;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JPopupMenu jPopupMenu3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane35;
    private javax.swing.JScrollPane jScrollPane37;
    private javax.swing.JScrollPane jScrollPane38;
    private javax.swing.JScrollPane jScrollPane39;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane40;
    private javax.swing.JScrollPane jScrollPane41;
    private javax.swing.JScrollPane jScrollPane42;
    private javax.swing.JScrollPane jScrollPane43;
    private javax.swing.JScrollPane jScrollPane44;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable10;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable12;
    private javax.swing.JTable jTable13;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTable jTable9;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextPane jcode;
    private javax.swing.JTextPane jcode1;
    private javax.swing.JTextPane jnom;
    private javax.swing.JTextPane jphone;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JMenuItem pasteMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JLabel txt;
    private javax.swing.JLabel txt1;
    private javax.swing.JLabel txt10;
    private javax.swing.JLabel txt11;
    private javax.swing.JLabel txt12;
    private javax.swing.JLabel txt13;
    private javax.swing.JLabel txt14;
    private javax.swing.JLabel txt15;
    private javax.swing.JLabel txt16;
    private javax.swing.JLabel txt17;
    private javax.swing.JLabel txt18;
    private javax.swing.JLabel txt19;
    private javax.swing.JLabel txt2;
    private javax.swing.JLabel txt20;
    private javax.swing.JLabel txt21;
    private javax.swing.JLabel txt22;
    private javax.swing.JLabel txt23;
    private javax.swing.JLabel txt24;
    private javax.swing.JLabel txt3;
    private javax.swing.JLabel txt4;
    private javax.swing.JLabel txt5;
    private javax.swing.JLabel txt6;
    private javax.swing.JLabel txt7;
    private javax.swing.JLabel txt8;
    private javax.swing.JLabel txt9;
    private javax.swing.JTextField txtaddress;
    private javax.swing.JTextField txtadress1;
    private javax.swing.JTextField txtcin;
    private javax.swing.JTextField txtcin1;
    private javax.swing.JComboBox<String> txtcom;
    private javax.swing.JComboBox<String> txtcom1;
    private javax.swing.JFormattedTextField txtdate;
    private javax.swing.JFormattedTextField txtdate1;
    private javax.swing.JFormattedTextField txtdate2;
    private javax.swing.JFormattedTextField txtdate3;
    private javax.swing.JFormattedTextField txtdate4;
    private javax.swing.JFormattedTextField txtdate5;
    private javax.swing.JTextArea txtdiagno2;
    private javax.swing.JTextArea txtdiagno3;
    private javax.swing.JComboBox<String> txtheure;
    private javax.swing.JComboBox<String> txtheure1;
    private javax.swing.JTextPane txtmotif;
    private javax.swing.JTextPane txtmotif1;
    private javax.swing.JTextPane txtmotif10;
    private javax.swing.JTextField txtmotif2;
    private javax.swing.JTextField txtmotif3;
    private javax.swing.JTextPane txtmotif8;
    private javax.swing.JTextPane txtmotif9;
    private javax.swing.JTextField txtmutuelle;
    private javax.swing.JTextField txtmutuelle1;
    private javax.swing.JTextField txtnom;
    private javax.swing.JTextField txtnom1;
    private javax.swing.JTextField txtphone;
    private javax.swing.JTextField txtphone1;
    private javax.swing.JTextField txtprofession;
    private javax.swing.JTextField txtprofession1;
    private javax.swing.JTextField txtsituation;
    private javax.swing.JTextField txtsituation1;
    private javax.swing.JComboBox<String> txtstatus;
    private javax.swing.JComboBox<String> txtstatus1;
    private javax.swing.JComboBox<String> txtstatus2;
    private javax.swing.JComboBox<String> txtstatus3;
    // End of variables declaration//GEN-END:variables

}
